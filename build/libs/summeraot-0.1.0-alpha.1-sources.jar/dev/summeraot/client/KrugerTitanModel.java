package dev.summeraot.client;

import dev.summeraot.entity.KrugerTitanEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

/** A mesma geometria e 37 sequências GeckoLib do SpringAOT, novo namespace. */
public final class KrugerTitanModel extends GeoModel<KrugerTitanEntity> {
    private static final class_2960 MODEL = class_2960.method_60655("summeraot", "geo/attack3titan.geo.json");
    private static final class_2960 TEXTURE = class_2960.method_60655("summeraot", "textures/entity/attack3titan.png");
    private static final class_2960 ANIMATION = class_2960.method_60655("summeraot", "animations/attack3titan.animation.json");

    @Override
    public class_2960 getModelResource(KrugerTitanEntity entity) { return MODEL; }
    @Override
    public class_2960 getTextureResource(KrugerTitanEntity entity) { return TEXTURE; }
    @Override
    public class_2960 getAnimationResource(KrugerTitanEntity entity) { return ANIMATION; }
}
