package dev.summeraot;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.summeraot.entity.KrugerTitanEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Seleção da variante exige que o jogador já seja Attack shifter do DAOT.
 * Comandos de teste não concedem poder nem alteram flags de autorização do DAOT.
 */
public final class KrugerCommands {
    private KrugerCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("summeraot")
                .then(class_2170.method_9247("kruger")
                    .then(class_2170.method_9247("select").executes(ctx -> select(ctx.getSource(), true)))
                    .then(class_2170.method_9247("vanilla").executes(ctx -> select(ctx.getSource(), false)))
                    .then(class_2170.method_9247("summon")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> summon(ctx.getSource())))));
        });
    }

    private static int select(class_2168 source, boolean kruger) {
        class_3222 player;
        try { player = source.method_9207(); }
        catch (Exception e) { return 0; }
        if (!player.method_5752().contains("attack")) {
            source.method_9213(class_2561.method_43470("SummerAOT: o DAOT deve reconhecer seu poder Attack primeiro."));
            return 0;
        }
        if (kruger) { player.method_5780("attack_3"); }
        else { player.method_5738("attack_3"); }
        source.method_9226(() -> class_2561.method_43470(
            kruger ? "Kruger selecionado para o próximo shift Attack." : "Forma original Attack selecionada."
        ), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int summon(class_2168 source) {
        class_3218 world = source.method_9225();
        KrugerTitanEntity titan = SummerAOTEntities.KRUGER.method_5883(world);
        if (titan == null) { return 0; }
        titan.method_5808(source.method_9222().field_1352, source.method_9222().field_1351,
            source.method_9222().field_1350, source.method_9210().field_1342, 0.0f);
        if (!world.method_8649(titan)) { return 0; }
        titan.spawnHitboxes();
        source.method_9226(() -> class_2561.method_43470("Kruger criado para teste visual."), true);
        return Command.SINGLE_SUCCESS;
    }
}
