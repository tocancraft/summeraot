package dev.summeraot.entity;

import daot.AttackTitanEntity;
import dev.summeraot.SummerAOTEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/**
 * Variante de Kruger: reaproveita movimentação, controles, ataques, stamina,
 * endurecimento, berserk, bossbar e animações do DAOT.
 * Substitui somente as hitboxes e o recurso visual.
 */
public class KrugerTitanEntity extends AttackTitanEntity {
    public KrugerTitanEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    @Override
    public void spawnHitboxes() {
        if (method_37908().field_9236) {
            return;
        }
        if (napeEntity != null && !napeEntity.method_31481()
                && eyeEntity != null && !eyeEntity.method_31481()
                && grabHitboxEntity != null && !grabHitboxEntity.method_31481()) {
            return;
        }
        discardExistingHitboxes();

        KrugerNapeEntity nape = new KrugerNapeEntity(SummerAOTEntities.KRUGER_NAPE, method_37908());
        KrugerEyeEntity eye = new KrugerEyeEntity(SummerAOTEntities.KRUGER_EYE, method_37908());
        KrugerGrabEntity grab = new KrugerGrabEntity(SummerAOTEntities.KRUGER_GRAB, method_37908());
        nape.setParentTitan(this);
        eye.setParentTitan(this);
        grab.setParentTitan(this);
        nape.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        eye.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        grab.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());

        boolean okNape = method_37908().method_8649(nape);
        boolean okEye = okNape && method_37908().method_8649(eye);
        boolean okGrab = okEye && method_37908().method_8649(grab);
        if (!okGrab) {
            if (okNape) { nape.method_31472(); }
            if (okEye) { eye.method_31472(); }
            return;
        }
        napeEntity = nape;
        eyeEntity = eye;
        grabHitboxEntity = grab;
    }

    private void discardExistingHitboxes() {
        if (napeEntity != null && !napeEntity.method_31481()) { napeEntity.method_31472(); }
        if (eyeEntity != null && !eyeEntity.method_31481()) { eyeEntity.method_31472(); }
        if (grabHitboxEntity != null && !grabHitboxEntity.method_31481()) { grabHitboxEntity.method_31472(); }
        napeEntity = null;
        eyeEntity = null;
        grabHitboxEntity = null;
    }

    @Override
    public void onPlayerShift(class_1657 player) {
        super.onPlayerShift(player);
        if (bossBar != null) {
            String label = player.method_5752().contains("titan_stealth")
                ? "Attack Titan 3"
                : player.method_5477().getString() + " - Attack Titan 3";
            bossBar.method_5413(class_2561.method_43470(label));
        }
    }
}
