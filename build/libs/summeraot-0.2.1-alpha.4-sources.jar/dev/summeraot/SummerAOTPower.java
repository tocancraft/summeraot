package dev.summeraot;

import net.minecraft.class_3222;

/**
 * Poder proprio do SummerAOT. Nao atribui a tag 'attack' do DAOT.
 * A tag Minecraft persiste com os dados do jogador entre sessoes.
 * Concessao/revogacao sao restritas a operadores nos comandos do addon.
 */
public final class SummerAOTPower {
    public static final String KRUGGER_TAG = "summeraot.power.krugger";

    private SummerAOTPower() {}

    public static boolean hasKrugger(class_3222 player) {
        return player.method_5752().contains(KRUGGER_TAG);
    }

    public static boolean grantKrugger(class_3222 player) {
        return player.method_5780(KRUGGER_TAG);
    }

    public static boolean revokeKrugger(class_3222 player) {
        return player.method_5738(KRUGGER_TAG);
    }
}
