package dev.summeraot;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import daot.HandcuffsTracker;
import dev.summeraot.entity.KrugerTitanEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Collection;

/**
 * Comandos da primeira versao independente do Krugger.
 * Os poderes NAO exigem nem concedem a tag 'attack' do DAOT.
 * grant/revoke/summon exigem operador; shift exige posse do poder SummerAOT.
 */
public final class KrugerCommands {
    private static CommandDispatcher<class_2168> activeDispatcher;

    private KrugerCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            activeDispatcher = dispatcher;
            dispatcher.register(class_2170.method_9247("summeraot")
                .then(class_2170.method_9247("krugger")
                    .then(class_2170.method_9247("status")
                        .executes(ctx -> status(ctx.getSource())))
                    .then(class_2170.method_9247("daotcheck")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> daotCheck(ctx.getSource())))
                    .then(class_2170.method_9247("shift")
                        .executes(ctx -> shift(ctx.getSource())))
                    .then(class_2170.method_9247("grant")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> grant(ctx.getSource(),
                                class_2186.method_9315(ctx, "player")))))
                    .then(class_2170.method_9247("revoke")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> revoke(ctx.getSource(),
                                class_2186.method_9315(ctx, "player")))))
                    .then(class_2170.method_9247("summon")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> summon(ctx.getSource())))));
            // Fabric callback: registration does not depend on intercepting DAOT bytecode.
            // Brigadier merges these nodes with DAOT's existing root and subcommands.
            registerDaotKrugger(dispatcher);
        });
    }

    private static void registerDaotKrugger(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("daot")
            .then(class_2170.method_9247("shifter")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("set")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("krugger")
                            .executes(ctx -> daotGrant(ctx)))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("krugger")
                            .executes(ctx -> daotRevoke(ctx)))))));
        boolean registered = isDaotKruggerAvailable(dispatcher, "set")
            && isDaotKruggerAvailable(dispatcher, "remove");
        SummerAOTMod.LOGGER.info("SummerAOT: DAOT bridge registered={}, set={}, remove={}",
            registered, isDaotKruggerAvailable(dispatcher, "set"),
            isDaotKruggerAvailable(dispatcher, "remove"));
    }

    private static boolean isDaotKruggerAvailable(
            CommandDispatcher<class_2168> dispatcher, String action) {
        if (dispatcher == null) { return false; }
        CommandNode<class_2168> root = dispatcher.getRoot().getChild("daot");
        CommandNode<class_2168> shifter = root == null ? null : root.getChild("shifter");
        CommandNode<class_2168> operation = shifter == null ? null : shifter.getChild(action);
        CommandNode<class_2168> targets = operation == null ? null : operation.getChild("targets");
        return targets != null && targets.getChild("krugger") != null;
    }

    private static int daotCheck(class_2168 source) {
        boolean set = isDaotKruggerAvailable(activeDispatcher, "set");
        boolean remove = isDaotKruggerAvailable(activeDispatcher, "remove");
        source.method_9226(() -> class_2561.method_43470(
            "SummerAOT /daot: set=" + set + ", remove=" + remove
                + ". Se ambos forem true e o comando falhar, envie latest.log e o erro do chat."), false);
        return (set && remove) ? 1 : 0;
    }

    private static int daotGrant(CommandContext<class_2168> ctx)
            throws CommandSyntaxException {
        Collection<class_3222> players = class_2186.method_9312(ctx, "targets");
        int changed = 0;
        for (class_3222 player : players) {
            if (SummerAOTPower.grantKrugger(player)) { changed++; }
        }
        int count = changed;
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "SummerAOT: Krugger Titan concedido a " + count + " jogador(es)."), true);
        return changed;
    }

    private static int daotRevoke(CommandContext<class_2168> ctx)
            throws CommandSyntaxException {
        Collection<class_3222> players = class_2186.method_9312(ctx, "targets");
        int changed = 0;
        for (class_3222 player : players) {
            if (SummerAOTPower.revokeKrugger(player)) { changed++; }
        }
        int count = changed;
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "SummerAOT: Krugger Titan removido de " + count + " jogador(es)."), true);
        return changed;
    }

    private static int status(class_2168 source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_3222 player = source.method_9207();
        boolean owns = SummerAOTPower.hasKrugger(player);
        source.method_9226(() -> class_2561.method_43470(
            "SummerAOT Krugger Titan: " + (owns ? "poder ativo" : "poder nao concedido")), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int grant(class_2168 source, class_3222 target) {
        boolean added = SummerAOTPower.grantKrugger(target);
        source.method_9226(() -> class_2561.method_43470("SummerAOT: poder Krugger " +
            (added ? "concedido a " : "ja presente em ") + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }

    private static int revoke(class_2168 source, class_3222 target) {
        boolean removed = SummerAOTPower.revokeKrugger(target);
        source.method_9226(() -> class_2561.method_43470("SummerAOT: poder Krugger " +
            (removed ? "revogado de " : "nao estava presente em ") + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }

    private static int shift(class_2168 source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_3222 player = source.method_9207();
        if (!SummerAOTPower.hasKrugger(player)) {
            source.method_9213(class_2561.method_43470("Voce nao possui o poder Krugger do SummerAOT."));
            return 0;
        }
        if (!player.method_5805() || player.method_7325() || player.method_5765()) {
            source.method_9213(class_2561.method_43470("Nao e possivel se transformar neste estado."));
            return 0;
        }
        if (HandcuffsTracker.isCuffed(player.method_5667())) {
            source.method_9213(class_2561.method_43470("Nao e possivel se transformar enquanto estiver algemado."));
            return 0;
        }
        class_3218 world = player.method_51469();
        KrugerTitanEntity titan = SummerAOTEntities.KRUGER.method_5883(world);
        if (titan == null) {
            source.method_9213(class_2561.method_43470("Falha ao criar a entidade Krugger."));
            return 0;
        }
        titan.method_5808(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455());
        titan.setHardeningMode(0);
        if (!world.method_8649(titan)) {
            source.method_9213(class_2561.method_43470("Nao foi possivel invocar o Krugger Titan."));
            return 0;
        }
        titan.spawnHitboxes();
        // Usa a inicializacao de shifter do DAOT, mas somente APOS a verificacao
        // do nosso poder independente. Nao altera a flag 'attack' do DAOT.
        titan.onPlayerShift(player);
        if (player.method_5854() != titan) {
            source.method_9213(class_2561.method_43470("Krugger criado, mas o jogador nao conseguiu montar. Verifique latest.log."));
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("Voce se transformou no Krugger Titan."), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int summon(class_2168 source) {
        class_3218 world = source.method_9225();
        KrugerTitanEntity titan = SummerAOTEntities.KRUGER.method_5883(world);
        if (titan == null) { return 0; }
        titan.method_5808(source.method_9222().field_1352, source.method_9222().field_1351,
            source.method_9222().field_1350, source.method_9210().field_1342, 0.0f);
        if (!world.method_8649(titan)) { return 0; }
        titan.spawnHitboxes();
        source.method_9226(() -> class_2561.method_43470("Krugger Titan invocado para teste."), true);
        return Command.SINGLE_SUCCESS;
    }
}
