package dev.summeraot;

import dev.summeraot.network.OmniKruggerNetwork;
import net.minecraft.class_3222;

/**
 * Estado de Krugger separado dos oito TitanPowerType nativos do DAOT.
 * Tag de posse e tag de seleção são persistidas no jogador.
 * Um jogador pode possuir Attack e Krugger simultaneamente.
 */
public final class SummerAOTPower {
    public static final String KRUGGER_TAG = "summeraot.power.krugger";
    public static final String KRUGGER_ACTIVE_TAG = "summeraot.selection.krugger";

    public static final String GRISHA_TAG = "summeraot.power.grisha";
    public static final String GRISHA_ACTIVE_TAG = "summeraot.selection.grisha";

    public static final String ARMIN_TAG = "summeraot.power.armin";
    public static final String ARMIN_ACTIVE_TAG = "summeraot.selection.armin";

    private SummerAOTPower() {}

    public static boolean hasKrugger(class_3222 player) {
        return player.method_5752().contains(KRUGGER_TAG);
    }

    public static boolean isKruggerSelected(class_3222 player) {
        return hasKrugger(player) && player.method_5752().contains(KRUGGER_ACTIVE_TAG);
    }

    public static boolean grantKrugger(class_3222 player) {
        boolean granted = player.method_5780(KRUGGER_TAG);
        // Conceder nao implica selecionar: a escolha pertence ao OmniShifter.
        // Quem ja tinha Krugger selecionado em uma versao anterior mantem sua escolha.
        OmniKruggerNetwork.sync(player);
        return granted;
    }

    public static boolean revokeKrugger(class_3222 player) {
        player.method_5738(KRUGGER_ACTIVE_TAG);
        boolean changed = player.method_5738(KRUGGER_TAG);
        OmniKruggerNetwork.sync(player);
        return changed;
    }

    public static boolean selectKrugger(class_3222 player) {
        if (!hasKrugger(player)) return false;
        boolean changed = player.method_5780(KRUGGER_ACTIVE_TAG);
        changed |= player.method_5738(GRISHA_ACTIVE_TAG);
        changed |= player.method_5738(ARMIN_ACTIVE_TAG);
        OmniKruggerNetwork.sync(player);
        return changed;
    }

    public static boolean hasGrisha(class_3222 player) {
        return player.method_5752().contains(GRISHA_TAG);
    }

    public static boolean isGrishaSelected(class_3222 player) {
        return hasGrisha(player) && player.method_5752().contains(GRISHA_ACTIVE_TAG);
    }

    public static boolean grantGrisha(class_3222 player) {
        boolean added = player.method_5780(GRISHA_TAG);
        OmniKruggerNetwork.sync(player);
        return added;
    }

    public static boolean revokeGrisha(class_3222 player) {
        player.method_5738(GRISHA_ACTIVE_TAG);
        boolean removed = player.method_5738(GRISHA_TAG);
        OmniKruggerNetwork.sync(player);
        return removed;
    }

    public static boolean selectGrisha(class_3222 player) {
        if (!hasGrisha(player)) return false;
        boolean changed = player.method_5780(GRISHA_ACTIVE_TAG);
        changed |= player.method_5738(KRUGGER_ACTIVE_TAG);
        changed |= player.method_5738(ARMIN_ACTIVE_TAG);
        OmniKruggerNetwork.sync(player);
        return changed;
    }

    public static boolean hasArmin(class_3222 player) {
        return player.method_5752().contains(ARMIN_TAG);
    }

    public static boolean isArminSelected(class_3222 player) {
        return hasArmin(player) && player.method_5752().contains(ARMIN_ACTIVE_TAG);
    }

    public static boolean grantArmin(class_3222 player) {
        boolean added = player.method_5780(ARMIN_TAG);
        OmniKruggerNetwork.sync(player);
        return added;
    }

    public static boolean revokeArmin(class_3222 player) {
        player.method_5738(ARMIN_ACTIVE_TAG);
        boolean removed = player.method_5738(ARMIN_TAG);
        OmniKruggerNetwork.sync(player);
        return removed;
    }

    public static boolean selectArmin(class_3222 player) {
        if (!hasArmin(player)) return false;
        boolean changed = player.method_5780(ARMIN_ACTIVE_TAG);
        changed |= player.method_5738(KRUGGER_ACTIVE_TAG);
        changed |= player.method_5738(GRISHA_ACTIVE_TAG);
        OmniKruggerNetwork.sync(player);
        return changed;
    }

    public static boolean selectVanilla(class_3222 player) {
        boolean changed = player.method_5738(KRUGGER_ACTIVE_TAG);
        changed |= player.method_5738(GRISHA_ACTIVE_TAG);
        changed |= player.method_5738(ARMIN_ACTIVE_TAG);
        OmniKruggerNetwork.sync(player);
        return changed;
    }
}
