package dev.summeraot.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Requisicao cliente; posse/cooldown validados apenas no servidor. */
public record ArminSelectC2SPayload() implements class_8710 {
    public static final class_9154<ArminSelectC2SPayload> ID =
            new class_9154<>(class_2960.method_60655("summeraot", "select_armin"));
    public static final class_9139<class_9129, ArminSelectC2SPayload> CODEC =
            class_9139.method_56438((packet, buf) -> {}, buf -> new ArminSelectC2SPayload());
    @Override public class_9154<? extends class_8710> method_56479() { return ID; }
}
