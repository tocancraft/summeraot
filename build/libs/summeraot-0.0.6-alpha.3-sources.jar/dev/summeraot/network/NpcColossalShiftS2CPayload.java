package dev.summeraot.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Posicao do efeito Effekseer nuclear original do DAOT na transformacao do NPC Armin. */
public record NpcColossalShiftS2CPayload(double x, double y, double z) implements class_8710 {
    public static final class_9154<NpcColossalShiftS2CPayload> ID =
            new class_9154<>(class_2960.method_60655("summeraot", "npc_colossal_shift"));
    public static final class_9139<class_9129, NpcColossalShiftS2CPayload> CODEC =
            class_9139.method_56438((packet, buffer) -> {
                buffer.method_52940(packet.x());
                buffer.method_52940(packet.y());
                buffer.method_52940(packet.z());
            }, buffer -> new NpcColossalShiftS2CPayload(
                    buffer.readDouble(), buffer.readDouble(), buffer.readDouble()));

    @Override
    public class_9154<? extends class_8710> method_56479() { return ID; }
}
