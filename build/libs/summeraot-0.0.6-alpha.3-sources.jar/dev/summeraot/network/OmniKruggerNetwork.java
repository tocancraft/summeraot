package dev.summeraot.network;

import dev.summeraot.SummerAOTMod;
import dev.summeraot.SummerAOTPower;
import daot.TitanPowerType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Bridges independent SummerAOT powers with the embedded OmniShifter 1.3.0. */
public final class OmniKruggerNetwork {
    private static final Set<UUID> NATIVE_SWITCHES = new HashSet<>();
    private static final long COOLDOWN_MS = 30_000L; // OmniShifter 1.3.0 server cooldown
    private OmniKruggerNetwork() {}

    public static void register() {
        PayloadTypeRegistry.playC2S().register(KruggerSelectC2SPayload.ID, KruggerSelectC2SPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GrishaSelectC2SPayload.ID, GrishaSelectC2SPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ArminSelectC2SPayload.ID, ArminSelectC2SPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(KruggerStateS2CPayload.ID, KruggerStateS2CPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(KruggerSelectC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> selectKrugger(context.player())));
        ServerPlayNetworking.registerGlobalReceiver(GrishaSelectC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> selectGrisha(context.player())));
        ServerPlayNetworking.registerGlobalReceiver(ArminSelectC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> selectArmin(context.player())));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                server.execute(() -> sync(handler.field_14140)));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> sync(newPlayer));
        // Native selections are marked only after Omni has ACCEPTED them (see OmniNativeSelectMixin).
        ServerTickEvents.END_SERVER_TICK.register(OmniKruggerNetwork::completeNativeSwitches);
    }

    /**
     * Called from OmniShifter's accepted native selection, immediately BEFORE
     * its TitanPowerTracker.syncPlayer(...). The DAOT command has already changed
     * the player's active native tag, but Omni's persisted lastActivePower can
     * still contain the PREVIOUS titan until its periodic tracker runs.
     *
     * Updating the original Omni state here makes BOTH Omni's SyncPowersS2C
     * and our own KruggerStateS2C report the same committed power.
     */
    public static void markNativeSelected(class_3222 player, Object omniState) {
        TitanPowerType accepted = null;
        for (TitanPowerType candidate : TitanPowerType.values()) {
            if (player.method_5752().contains(candidate.getTagName())) {
                accepted = candidate;
                break;
            }
        }
        if (accepted == null) {
            SummerAOTMod.LOGGER.warn("Omni aceitou uma selecao, mas nenhuma tag nativa ativa foi encontrada para {}", player.method_5477().getString());
        } else {
            try {
                Method setter = omniState.getClass().getMethod("setLastActivePower", UUID.class, TitanPowerType.class);
                setter.invoke(omniState, player.method_5667(), accepted);
            } catch (ReflectiveOperationException | LinkageError ex) {
                SummerAOTMod.LOGGER.error("Nao foi possivel confirmar o poder nativo no estado do OmniShifter", ex);
            }
        }
        NATIVE_SWITCHES.add(player.method_5667());
    }

    private static void completeNativeSwitches(MinecraftServer server) {
        if (NATIVE_SWITCHES.isEmpty()) return;
        Set<UUID> accepted = new HashSet<>(NATIVE_SWITCHES);
        NATIVE_SWITCHES.clear();
        for (UUID id : accepted) {
            class_3222 player = server.method_3760().method_14602(id);
            if (player == null) continue;
            SummerAOTPower.selectVanilla(player);
            sync(player);
        }
    }

    private static void selectKrugger(class_3222 player) {
        if (!SummerAOTPower.hasKrugger(player)) {
            player.method_7353(class_2561.method_43470("SummerAOT: voce nao possui Krugger Titan."), true);
            sync(player);
            return;
        }
        if (SummerAOTPower.isKruggerSelected(player)) {
            sync(player);
            return;
        }
        if (!player.method_5805() || player.method_7325() || player.method_5765()) {
            player.method_7353(class_2561.method_43470("SummerAOT: nao e possivel trocar enquanto transformado."), true);
            sync(player);
            return;
        }
        long now = System.currentTimeMillis();
        long previous = nativeCooldownSince(player.method_5667());
        if (!player.method_7337() && now - previous < COOLDOWN_MS) {
            long remaining = Math.max(1, (COOLDOWN_MS - (now - previous) + 999) / 1000);
            player.method_7353(class_2561.method_43470("SummerAOT: aguarde " + remaining + "s para trocar de tita."), true);
            sync(player);
            return;
        }
        SummerAOTPower.selectKrugger(player);
        if (!player.method_7337()) setNativeCooldownSince(player.method_5667(), now);
        // The OmniShifter's native selection creates a cosmetic lightning bolt
        // and plays thunder/impact sounds. Krugger must have the same feedback.
        strikeCosmeticLightning(player);
        player.method_7353(class_2561.method_43470("Poder ativo: Krugger Titan"), true);
        sync(player);
    }

    private static void selectGrisha(class_3222 player) {
        if (!SummerAOTPower.hasGrisha(player)) {
            player.method_7353(class_2561.method_43470("SummerAOT: voce nao possui Grisha Titan."), true);
            sync(player);
            return;
        }
        if (SummerAOTPower.isGrishaSelected(player)) {
            sync(player);
            return;
        }
        if (!player.method_5805() || player.method_7325() || player.method_5765()) {
            player.method_7353(class_2561.method_43470("SummerAOT: nao e possivel trocar enquanto transformado."), true);
            sync(player);
            return;
        }
        long now = System.currentTimeMillis();
        long previous = nativeCooldownSince(player.method_5667());
        if (!player.method_7337() && now - previous < COOLDOWN_MS) {
            long remaining = Math.max(1, (COOLDOWN_MS - (now - previous) + 999) / 1000);
            player.method_7353(class_2561.method_43470("SummerAOT: aguarde " + remaining + "s para trocar de tita."), true);
            sync(player);
            return;
        }
        SummerAOTPower.selectGrisha(player);
        if (!player.method_7337()) setNativeCooldownSince(player.method_5667(), now);
        strikeCosmeticLightning(player);
        player.method_7353(class_2561.method_43470("Poder ativo: Grisha Titan"), true);
        sync(player);
    }

    private static void selectArmin(class_3222 player) {
        if (!SummerAOTPower.hasArmin(player)) {
            player.method_7353(class_2561.method_43470("SummerAOT: voce nao possui o Colossal do Armin."), true);
            sync(player);
            return;
        }
        if (SummerAOTPower.isArminSelected(player)) {
            sync(player);
            return;
        }
        if (!player.method_5805() || player.method_7325() || player.method_5765()) {
            player.method_7353(class_2561.method_43470("SummerAOT: nao e possivel trocar enquanto transformado."), true);
            sync(player);
            return;
        }
        long now = System.currentTimeMillis();
        long previous = nativeCooldownSince(player.method_5667());
        if (!player.method_7337() && now - previous < COOLDOWN_MS) {
            long remaining = Math.max(1, (COOLDOWN_MS - (now - previous) + 999) / 1000);
            player.method_7353(class_2561.method_43470("SummerAOT: aguarde " + remaining + "s para trocar de tita."), true);
            sync(player);
            return;
        }
        SummerAOTPower.selectArmin(player);
        if (!player.method_7337()) setNativeCooldownSince(player.method_5667(), now);
        strikeCosmeticLightning(player);
        player.method_7353(class_2561.method_43470("Poder ativo: Colossal do Armin"), true);
        sync(player);
    }

    private static void strikeCosmeticLightning(class_3222 player) {
        if (!(player.method_37908() instanceof class_3218 world)) return;
        class_1538 lightning = class_1299.field_6112.method_5883(world);
        if (lightning == null) return;
        lightning.method_29495(player.method_19538());
        lightning.method_29498(true); // FX only, no damage or fire.
        world.method_8649(lightning);
        world.method_8396(null, player.method_24515(), class_3417.field_14865,
                class_3419.field_15252, 10000.0f, 0.8f + world.field_9229.method_43057() * 0.2f);
        world.method_8396(null, player.method_24515(), class_3417.field_14956,
                class_3419.field_15252, 2.0f, 0.5f + world.field_9229.method_43057() * 0.2f);
    }

    public static void sync(class_3222 player) {
        if (player == null || player.method_14239()) return;
        long since = nativeCooldownSince(player.method_5667());
        long ends = since == 0 || player.method_7337() ? 0 : since + COOLDOWN_MS;
        ServerPlayNetworking.send(player, new KruggerStateS2CPayload(
                SummerAOTPower.hasKrugger(player),
                SummerAOTPower.isKruggerSelected(player),
                nativeSelectedOrdinal(player), ends,
                SummerAOTPower.hasGrisha(player), SummerAOTPower.isGrishaSelected(player),
                SummerAOTPower.hasArmin(player), SummerAOTPower.isArminSelected(player)));
    }

    /** Read the authoritative native active power from the Omni persistent state. */
    private static int nativeSelectedOrdinal(class_3222 player) {
        try {
            Class<?> stateClass = Class.forName("com.omnishifter.data.PlayerTitanPowersState");
            Object state = stateClass.getMethod("getServerState", MinecraftServer.class)
                    .invoke(null, player.method_5682());
            Object last = stateClass.getMethod("getLastActivePower", UUID.class)
                    .invoke(state, player.method_5667());
            return last instanceof TitanPowerType power ? power.ordinal() : -1;
        } catch (ReflectiveOperationException | LinkageError ex) {
            SummerAOTMod.LOGGER.error("Nao foi possivel ler a selecao nativa do OmniShifter", ex);
            return -1;
        }
    }

    /* OmniShifter is embedded as a Fabric nested JAR. Its public cooldown map is
       accessed reflectively so it need not be a compilation dependency. */
    @SuppressWarnings("unchecked")
    private static Map<UUID, Long> nativeCooldowns() {
        try {
            Class<?> omni = Class.forName("com.omnishifter.OmniShifter");
            Field field = omni.getField("playerCooldowns");
            return (Map<UUID, Long>) field.get(null);
        } catch (ReflectiveOperationException | LinkageError ex) {
            SummerAOTMod.LOGGER.error("OmniShifter cooldowns indisponiveis", ex);
            return Map.of();
        }
    }
    private static long nativeCooldownSince(UUID id) {
        return nativeCooldowns().getOrDefault(id, 0L);
    }
    private static void setNativeCooldownSince(UUID id, long now) {
        try { nativeCooldowns().put(id, now); }
        catch (UnsupportedOperationException ex) {
            SummerAOTMod.LOGGER.error("OmniShifter cooldowns nao permitem gravacao", ex);
        }
    }
}
