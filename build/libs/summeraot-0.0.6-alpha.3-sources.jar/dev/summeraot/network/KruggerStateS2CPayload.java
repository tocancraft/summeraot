package dev.summeraot.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server-authoritative state so the Omni UI shows only powers actually owned. */
public record KruggerStateS2CPayload(boolean owned, boolean selected, int nativePowerOrdinal, long cooldownEndsAt,
                                    boolean grishaOwned, boolean grishaSelected, boolean arminOwned, boolean arminSelected)
        implements class_8710 {
    public static final class_9154<KruggerStateS2CPayload> ID =
            new class_9154<>(class_2960.method_60655("summeraot", "krugger_state"));
    public static final class_9139<class_9129, KruggerStateS2CPayload> CODEC =
            class_9139.method_56438((packet, buf) -> {
                buf.method_52964(packet.owned());
                buf.method_52964(packet.selected());
                buf.method_10804(packet.nativePowerOrdinal());
                buf.method_52974(packet.cooldownEndsAt());
                buf.method_52964(packet.grishaOwned());
                buf.method_52964(packet.grishaSelected());
                buf.method_52964(packet.arminOwned());
                buf.method_52964(packet.arminSelected());
            }, buf -> new KruggerStateS2CPayload(buf.readBoolean(), buf.readBoolean(), buf.method_10816(), buf.readLong(),
                buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479() { return ID; }
}
