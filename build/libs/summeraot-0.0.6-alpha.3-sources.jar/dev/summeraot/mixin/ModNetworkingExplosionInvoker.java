package dev.summeraot.mixin;

import daot.network.ModNetworking;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Reutiliza a onda de dano, empurrao e shake da transformacao nativa do DAOT. */
@Mixin(value = ModNetworking.class, remap = false)
public interface ModNetworkingExplosionInvoker {
    @Invoker("triggerTransformationExplosion")
    static void summeraot$triggerExplosion(class_3218 world, double x, double y,
            double z, class_3222 player, double radius, float damage,
            double knockback) {
        throw new AssertionError("Mixin invoker not applied");
    }
}
