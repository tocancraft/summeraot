package dev.summeraot.npc;

import daot.BloodlineData;
import daot.BloodlineType;
import dev.summeraot.SummerAOTPower;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** Seringa propria: nao consome slots no enum fechado de oito poderes do DAOT. */
public final class SummerSyringeItem extends class_1792 {
    private final ShifterVariant variant;

    public SummerSyringeItem(ShifterVariant variant) {
        super(new class_1792.class_1793().method_7889(1));
        this.variant = variant;
    }

    public ShifterVariant variant() {
        return variant;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(world instanceof class_3218 serverWorld) || !(player instanceof class_3222 serverPlayer)) {
            return class_1271.method_29237(stack, true);
        }
        if (variant == null) {
            serverPlayer.method_7353(class_2561.method_43470("Use esta seringa em um aldeao shifter ou Tita do SummerAOT."), true);
            return class_1271.method_22431(stack);
        }
        BloodlineType bloodline = BloodlineData.get(serverWorld).getBloodline(serverPlayer.method_5667());
        if (bloodline != BloodlineType.ELDIAN && bloodline != BloodlineType.ROYAL && !serverPlayer.method_7337()) {
            serverPlayer.method_7353(class_2561.method_43470("Apenas Eldianos e membros da linhagem real podem herdar um poder de Tita."), false);
            return class_1271.method_22431(stack);
        }
        boolean given = switch (variant) {
            case KRUGGER -> SummerAOTPower.grantKrugger(serverPlayer);
            case GRISHA -> SummerAOTPower.grantGrisha(serverPlayer);
            case ARMIN -> SummerAOTPower.grantArmin(serverPlayer);
        };
        if (!given) {
            serverPlayer.method_7353(class_2561.method_43470("Voce ja possui o poder de " + variant.label + "."), true);
            return class_1271.method_22431(stack);
        }
        serverPlayer.method_7353(class_2561.method_43470("Poder de " + variant.label + " adquirido. Selecione-o no OmniShifter."), false);
        if (!serverPlayer.method_7337()) {
            stack.method_7934(1);
            serverPlayer.method_7270(new class_1799(SummerNpcRegistry.EMPTY_SYRINGE));
        }
        return class_1271.method_29237(stack, false);
    }
}
