package dev.summeraot.npc;

import daot.AttackTitanEntity;
import daot.ColossalTitanEntity;
import daot.DannysAot;
import daot.TitanPowerData;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Transforma aldeoes portadores em titas IA e restaura a forma humana ao fim da luta. */
public final class SummerNpcLogic {
    public static final String NPC_TITAN_TAG = "summeraot.npc_titan";
    public static final String EXTRACTED_TAG = "summeraot.syringe_extracted";
    private static final String ENEMY = "summeraot.npc.enemy.";
    private static final String PROF = "summeraot.npc.prof.";
    private static final String LEVEL = "summeraot.npc.level.";
    private static final Map<UUID, UUID> ATTACKERS = new ConcurrentHashMap<>();

    private SummerNpcLogic() {}

    public static void initialize() {
        // Executa antes das interacoes padrao do aldeao (que abririam o menu de troca).
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            class_1799 stack = player.method_5998(hand);
            // A seringa vazia original do Danny's AoT tambem extrai
            // os tres novos poderes. O DAOT faz PASS para estes alvos.
            class_1792 held = stack.method_7909();
            boolean nativeEmpty = held == DannysAot.EMPTY_SYRINGE;
            if (!(held instanceof SummerSyringeItem) && !nativeEmpty) {
                return class_1269.field_5811;
            }
            ShifterVariant filledPower = held instanceof SummerSyringeItem filled ? filled.variant() : null;
            if (filledPower == null) {
                if (!(entity instanceof ShifterVillagerEntity)
                        && ShifterVariant.fromTitanType(entity.method_5864()) == null) {
                    return class_1269.field_5811;
                }
                if (world.field_9236) {
                    return class_1269.field_5812;
                }
                if (!(world instanceof class_3218 serverWorld)) {
                    return class_1269.field_5811;
                }
                ShifterVariant variant;
                if (entity instanceof ShifterVillagerEntity npc) {
                    variant = npc.variant();
                    // Aldeao perde o poder apos extracao do fluido: preserva prof./nivel.
                    class_1646 former = vanillaVillager(npc, serverWorld);
                    if (former == null || !serverWorld.method_8649(former)) {
                        return class_1269.field_5814;
                    }
                    npc.method_31472();
                } else {
                    variant = ShifterVariant.fromTitanType(entity.method_5864());
                    if (entity.method_5752().contains(EXTRACTED_TAG)) {
                        player.method_7353(class_2561.method_43470("Este Tita ja teve seu fluido extraido."), true);
                        return class_1269.field_5814;
                    }
                    if (entity.method_5752().contains(NPC_TITAN_TAG)
                            && entity instanceof class_1588 npcTitan) {
                        if (!disempowerTitan(npcTitan, serverWorld)) {
                            return class_1269.field_5814;
                        }
                    } else {
                        entity.method_5780(EXTRACTED_TAG);
                    }
                }
                if (variant == null) {
                    return class_1269.field_5811;
                }
                consumeAndGive(player, stack, SummerNpcRegistry.filled(variant));
                return class_1269.field_5812;
            }
            if (!(entity instanceof class_1646 villager)) {
                return class_1269.field_5811;
            }
            if (world.field_9236) {
                return class_1269.field_5812;
            }
            if (!(world instanceof class_3218 serverWorld)) {
                return class_1269.field_5811;
            }
            if (villager instanceof ShifterVillagerEntity) {
                player.method_7353(class_2561.method_43470("Este aldeao ja e portador de um poder SummerAOT."), true);
                return class_1269.field_5814;
            }
            if (TitanPowerData.get(serverWorld).hasPower(villager.method_5667())) {
                player.method_7353(class_2561.method_43470("Este aldeao ja possui um poder nativo do Danny's AOT."), true);
                return class_1269.field_5814;
            }
            ShifterVillagerEntity powered = createPoweredVillager(serverWorld, villager, filledPower);
            if (powered == null || !serverWorld.method_8649(powered)) {
                return class_1269.field_5814;
            }
            villager.method_31472();
            consumeAndGive(player, stack, SummerNpcRegistry.EMPTY_SYRINGE);
            player.method_7353(class_2561.method_43470("Aldeao agora possui o poder de " + filledPower.label + "."), true);
            return class_1269.field_5812;
        });
    }

    private static void consumeAndGive(class_1657 player, class_1799 stack, class_1792 item) {
        if (!player.method_7337()) {
            stack.method_7934(1);
        }
        class_1799 reward = new class_1799(item);
        if (!player.method_31548().method_7394(reward)) {
            player.method_7328(reward, false);
        }
    }

    private static ShifterVillagerEntity createPoweredVillager(class_3218 world, class_1646 villager, ShifterVariant variant) {
        ShifterVillagerEntity powered = SummerNpcRegistry.createVillager(variant, world);
        if (powered == null) return null;
        copyVillager(villager, powered);
        return powered;
    }

    private static class_1646 vanillaVillager(class_1646 npc, class_3218 world) {
        class_1646 vanilla = net.minecraft.class_1299.field_6077.method_5883(world);
        if (vanilla != null) copyVillager(npc, vanilla);
        return vanilla;
    }

    private static void copyVillager(class_1646 old, class_1646 created) {
        created.method_5808(old.method_23317(), old.method_23318(), old.method_23321(), old.method_36454(), old.method_36455());
        created.method_7195(old.method_7231());
        created.method_5614(old.method_5618());
        created.method_5665(old.method_5797());
        created.method_5880(old.method_5807());
        created.method_6033(Math.min(created.method_6063(), Math.max(1, old.method_6032())));
    }

    public static void onStartTransform(ShifterVillagerEntity villager, class_3218 world, class_1309 attacker) {
        if (attacker != null) {
            ATTACKERS.put(villager.method_5667(), attacker.method_5667());
        }
        // O raio e a explosao acontecem juntos ao surgir o tita (apos 40 ticks).
    }

    public static void completeTransform(ShifterVillagerEntity villager, class_3218 world) {
        ShifterVariant variant = villager.variant();
        if (variant == null || !villager.method_5805()) return;
        class_1588 titan = variant.newTitan(world);
        if (titan == null) return;
        titan.method_5808(villager.method_23317(), villager.method_23318(), villager.method_23321(), villager.method_36454(), 0f);
        titan.method_5780(NPC_TITAN_TAG);
        titan.method_5780(PROF + class_7923.field_41195.method_10221(villager.method_7231().method_16924()));
        titan.method_5780(LEVEL + villager.method_7231().method_16925());
        UUID attacker = ATTACKERS.remove(villager.method_5667());
        if (attacker != null) {
            titan.method_5780(ENEMY + attacker);
            class_1297 entity = world.method_14190(attacker);
            if (entity instanceof class_1309 living && living.method_5805()) {
                titan.method_5980(living);
            }
        }
        titan.method_5665(class_2561.method_43470(variant.label + " (shifter NPC)"));
        titan.method_5880(true);
        titan.method_5977(false);
        if (titan instanceof AttackTitanEntity attack) {
            attack.setTransformationTicks(80);
        } else if (titan instanceof ColossalTitanEntity colossal) {
            colossal.setTransformationTicks(80);
        }
        if (!world.method_8649(titan)) {
            villager.method_5684(false);
            return;
        }
        if (titan instanceof AttackTitanEntity attack) {
            attack.spawnHitboxes();
        } else if (titan instanceof ColossalTitanEntity colossal) {
            colossal.spawnHitboxes();
        }
        // Remove o aldeao antes da onda de dano, evitando reentrancia em damage().
        villager.method_31472();
        SummerNpcShiftEffects.onNpcShift(world, titan, variant);
    }

    /** Chamado somente pelos titas do SummerAOT; /summon e shifters jogadores nao sao alterados. */
    public static void tickNpcTitan(class_1588 titan) {
        if (titan.method_37908().field_9236 || !titan.method_5752().contains(NPC_TITAN_TAG)) return;
        if (!(titan.method_37908() instanceof class_3218 world)) return;
        ShifterVariant variant = ShifterVariant.fromTitanType(titan.method_5864());
        if (variant == null) return;
        if (titan.field_6012 > 20 * 80 || titan.method_6032() <= 1f) {
            restore(titan, world, variant);
            return;
        }
        if (titan.field_6012 % 15 != 0) return;
        class_1309 target = titan.method_5968();
        if (target == null || !target.method_5805() || target.method_31481()) {
            target = findTarget(titan, world);
        }
        if (target == null) {
            if (titan.field_6012 > 20 * 20) restore(titan, world, variant);
            return;
        }
        titan.method_5980(target);
        // Ataque, perseguição e animacoes sao controlados por AssaultGoal;
        // evita duplo golpe sem animacao via tryAttack().
    }

    private static class_1309 findTarget(class_1588 titan, class_3218 world) {
        for (String tag : titan.method_5752()) {
            if (tag.startsWith(ENEMY)) {
                try {
                    class_1297 candidate = world.method_14190(UUID.fromString(tag.substring(ENEMY.length())));
                    if (candidate instanceof class_1309 living && living.method_5805()) return living;
                } catch (IllegalArgumentException ignored) {
                    // Uma tag malformada nao pode causar crash do servidor.
                }
            }
        }
        for (class_1588 hostile : world.method_8390(class_1588.class,
                titan.method_5829().method_1014(20), other -> other != titan && other.method_5805()
                    && !other.method_5752().contains(NPC_TITAN_TAG))) {
            return hostile;
        }
        return null;
    }

    private static void restore(class_1588 titan, class_3218 world, ShifterVariant variant) {
        ShifterVillagerEntity restored = SummerNpcRegistry.createVillager(variant, world);
        if (restored == null) return;
        restoreVillagerDataFromTitan(titan, restored);
        restored.method_6033(restored.method_6063());
        if (world.method_8649(restored)) {
            titan.method_31472();
        }
    }

    /** A extracao de um NPC transformado remove o poder, nao apenas o fluido. */
    private static boolean disempowerTitan(class_1588 titan, class_3218 world) {
        class_1646 normal = net.minecraft.class_1299.field_6077.method_5883(world);
        if (normal == null) return false;
        restoreVillagerDataFromTitan(titan, normal);
        if (!world.method_8649(normal)) return false;
        titan.method_31472();
        return true;
    }

    private static void restoreVillagerDataFromTitan(class_1588 titan, class_1646 villager) {
        villager.method_5808(titan.method_23317(), titan.method_23318(), titan.method_23321(), titan.method_36454(), 0f);
        String profession = tagValue(titan, PROF);
        String level = tagValue(titan, LEVEL);
        if (profession != null) {
            class_2960 id = class_2960.method_12829(profession);
            if (id != null && class_7923.field_41195.method_10250(id)) {
                villager.method_7195(villager.method_7231().method_16921(class_7923.field_41195.method_10223(id)));
            }
        }
        if (level != null) {
            try {
                int value = Integer.parseInt(level);
                villager.method_7195(villager.method_7231().method_16920(Math.max(1, Math.min(5, value))));
            } catch (NumberFormatException ignored) {}
        }
    }

    private static String tagValue(class_1297 entity, String prefix) {
        for (String tag : entity.method_5752()) {
            if (tag.startsWith(prefix)) return tag.substring(prefix.length());
        }
        return null;
    }
}
