package dev.summeraot.npc;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_3218;
import org.joml.Vector3f;

/** Aldeao funcional (comercio, profissoes, IA vanilla) com identidade fixa. */
public final class ShifterVillagerEntity extends class_1646 {
    private int pendingShiftTicks;
    // Cores e tamanho identicos ao indicador dos aldeoes do DAOT 2.5.0.
    private static final class_2390 ATTACK_PARTICLE =
            new class_2390(new Vector3f(0.2f, 0.9f, 0.2f), 1.0f);
    private static final class_2390 COLOSSAL_PARTICLE =
            new class_2390(new Vector3f(0.9f, 0.2f, 0.2f), 1.0f);

    public ShifterVillagerEntity(class_1299<? extends class_1646> type, class_1937 world) {
        super(type, world);
    }

    public ShifterVariant variant() {
        return ShifterVariant.fromVillagerType(method_5864());
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (!method_37908().field_9236 && method_37908() instanceof class_3218 world
                && amount > 0.0f) {
            if (pendingShiftTicks > 0) {
                return false;
            }
            if (method_6032() - amount <= Math.max(1.0f, method_6063() * 0.70f)) {
                pendingShiftTicks = 40;
                method_6033(Math.max(1.0f, method_6032() - amount));
                class_1309 attacker = source.method_5529() instanceof class_1309 living
                        ? living : null;
                SummerNpcLogic.onStartTransform(this, world, attacker);
                return false;
            }
        }
        return super.method_5643(source, amount);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        // Sem rede adicional: cada cliente ja conhece o tipo do aldeao.
        // Repete o efeito Dust do PoweredVillagerParticleHandler do DAOT.
        if (method_37908().field_9236 && method_5805() && variant() != null) {
            class_2390 particle = variant() == ShifterVariant.ARMIN
                    ? COLOSSAL_PARTICLE : ATTACK_PARTICLE;
            for (int i = 0; i < 4; i++) {
                double dx = (field_5974.method_43058() - 0.5D) * 0.8D;
                double dy = (field_5974.method_43058() - 0.5D) * 1.2D;
                double dz = (field_5974.method_43058() - 0.5D) * 0.8D;
                method_37908().method_8406(particle, method_23317() + dx,
                        method_23318() + method_17682() * 0.5D + dy, method_23321() + dz,
                        0.0D, 0.02D, 0.0D);
            }
        }
        if (pendingShiftTicks > 0 && method_37908() instanceof class_3218 world) {
            pendingShiftTicks--;
            if (pendingShiftTicks == 0) {
                SummerNpcLogic.completeTransform(this, world);
            }
        }
    }
}
