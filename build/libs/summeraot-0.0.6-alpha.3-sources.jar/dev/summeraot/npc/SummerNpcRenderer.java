package dev.summeraot.npc;

import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_927;

/** Modelo PLAYER: as skins 64x64 nao sao UV de um aldeao vanilla. */
public final class SummerNpcRenderer extends class_927<ShifterVillagerEntity, class_591<ShifterVillagerEntity>> {
    private final class_2960 texture;

    public SummerNpcRenderer(class_5617.class_5618 context, ShifterVariant variant) {
        super(context, new class_591<ShifterVillagerEntity>(context.method_32167(class_5602.field_27577), false), 0.5f);
        this.texture = variant.skin();
    }

    @Override
    public class_2960 getTexture(ShifterVillagerEntity entity) {
        return texture;
    }
}
