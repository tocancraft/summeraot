package dev.summeraot.npc;

import dev.summeraot.SummerAOTEntities;
import dev.summeraot.armin.ArminColossalEntities;
import dev.summeraot.grisha.GrishaEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_2960;
import net.minecraft.class_3218;

/** Identidades independentes: nao altera TitanPowerType do DAOT. */
public enum ShifterVariant {
    KRUGGER("krugger", "Eren Krugger", "krugger_villager"),
    GRISHA("grisha", "Grisha Yeager", "grisha_villager"),
    ARMIN("armin", "Armin Arlert", "armin_villager");

    public final String key;
    public final String label;
    public final String villagerPath;

    ShifterVariant(String key, String label, String villagerPath) {
        this.key = key;
        this.label = label;
        this.villagerPath = villagerPath;
    }

    public class_2960 skin() {
        return class_2960.method_60655("summeraot", "textures/entity/npc/" + key + ".png");
    }

    public class_1299<? extends class_1588> titanType() {
        return switch (this) {
            case KRUGGER -> SummerAOTEntities.KRUGER;
            case GRISHA -> GrishaEntities.GRISHA_TITAN;
            case ARMIN -> ArminColossalEntities.ARMIN_COLOSSAL;
        };
    }

    public class_1588 newTitan(class_3218 world) {
        return titanType().method_5883(world);
    }

    public static ShifterVariant fromVillagerType(class_1299<?> type) {
        if (type == SummerNpcRegistry.KRUGGER_VILLAGER) return KRUGGER;
        if (type == SummerNpcRegistry.GRISHA_VILLAGER) return GRISHA;
        if (type == SummerNpcRegistry.ARMIN_VILLAGER) return ARMIN;
        return null;
    }

    public static ShifterVariant fromTitanType(class_1299<?> type) {
        if (type == SummerAOTEntities.KRUGER) return KRUGGER;
        if (type == GrishaEntities.GRISHA_TITAN) return GRISHA;
        if (type == ArminColossalEntities.ARMIN_COLOSSAL) return ARMIN;
        return null;
    }
}
