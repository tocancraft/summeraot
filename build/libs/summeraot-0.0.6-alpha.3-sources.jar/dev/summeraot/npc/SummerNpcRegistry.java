package dev.summeraot.npc;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public final class SummerNpcRegistry {
    private SummerNpcRegistry() {}

    private static class_1299<ShifterVillagerEntity> villager(String id) {
        return class_2378.method_10230(class_7923.field_41177, class_2960.method_60655("summeraot", id),
            class_1299.class_1300.method_5903(ShifterVillagerEntity::new, class_1311.field_17715)
                .method_17687(0.6f, 1.95f).method_55687(1.62f)
                .method_27299(10).method_27300(3)
                .method_5905("summeraot:" + id));
    }

    public static final class_1299<ShifterVillagerEntity> KRUGGER_VILLAGER = villager("krugger_villager");
    public static final class_1299<ShifterVillagerEntity> GRISHA_VILLAGER = villager("grisha_villager");
    public static final class_1299<ShifterVillagerEntity> ARMIN_VILLAGER = villager("armin_villager");

    private static class_1792 item(String id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("summeraot", id), item);
    }

    public static final class_1792 EMPTY_SYRINGE = item("empty_power_syringe", new SummerSyringeItem(null));
    public static final class_1792 KRUGGER_SYRINGE = item("krugger_syringe", new SummerSyringeItem(ShifterVariant.KRUGGER));
    public static final class_1792 GRISHA_SYRINGE = item("grisha_syringe", new SummerSyringeItem(ShifterVariant.GRISHA));
    public static final class_1792 ARMIN_SYRINGE = item("armin_syringe", new SummerSyringeItem(ShifterVariant.ARMIN));

    private static class_1792 egg(String id, class_1299<?> type, int base, int spots) {
        return item(id, new class_1826((class_1299) type, base, spots, new class_1792.class_1793()));
    }

    public static final class_1792 KRUGGER_VILLAGER_EGG = egg("krugger_villager_spawn_egg", KRUGGER_VILLAGER, 0x523E2F, 0xC9A184);
    public static final class_1792 GRISHA_VILLAGER_EGG = egg("grisha_villager_spawn_egg", GRISHA_VILLAGER, 0x3E2F2B, 0xC7A786);
    public static final class_1792 ARMIN_VILLAGER_EGG = egg("armin_villager_spawn_egg", ARMIN_VILLAGER, 0xD7C189, 0x64727F);
    public static final class_1792 KRUGGER_TITAN_EGG = egg("krugger_titan_spawn_egg", ShifterVariant.KRUGGER.titanType(), 0x9D4D3C, 0x3C302A);
    public static final class_1792 GRISHA_TITAN_EGG = egg("grisha_titan_spawn_egg", ShifterVariant.GRISHA.titanType(), 0x8D3D37, 0x42352D);
    public static final class_1792 ARMIN_TITAN_EGG = egg("armin_colossal_titan_spawn_egg", ShifterVariant.ARMIN.titanType(), 0xC74437, 0xF4D8B4);

    public static class_1792 filled(ShifterVariant variant) {
        return switch (variant) {
            case KRUGGER -> KRUGGER_SYRINGE;
            case GRISHA -> GRISHA_SYRINGE;
            case ARMIN -> ARMIN_SYRINGE;
        };
    }

    public static ShifterVillagerEntity createVillager(ShifterVariant variant, net.minecraft.class_3218 world) {
        return switch (variant) {
            case KRUGGER -> KRUGGER_VILLAGER.method_5883(world);
            case GRISHA -> GRISHA_VILLAGER.method_5883(world);
            case ARMIN -> ARMIN_VILLAGER.method_5883(world);
        };
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(KRUGGER_VILLAGER, class_1646.method_26955());
        FabricDefaultAttributeRegistry.register(GRISHA_VILLAGER, class_1646.method_26955());
        FabricDefaultAttributeRegistry.register(ARMIN_VILLAGER, class_1646.method_26955());
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            entries.method_45421(KRUGGER_VILLAGER_EGG);
            entries.method_45421(GRISHA_VILLAGER_EGG);
            entries.method_45421(ARMIN_VILLAGER_EGG);
            entries.method_45421(KRUGGER_TITAN_EGG);
            entries.method_45421(GRISHA_TITAN_EGG);
            entries.method_45421(ARMIN_TITAN_EGG);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(EMPTY_SYRINGE);
            entries.method_45421(KRUGGER_SYRINGE);
            entries.method_45421(GRISHA_SYRINGE);
            entries.method_45421(ARMIN_SYRINGE);
        });
    }
}
