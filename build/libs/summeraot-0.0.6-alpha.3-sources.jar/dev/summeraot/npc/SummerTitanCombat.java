package dev.summeraot.npc;

import daot.AttackTitanEntity;
import daot.ColossalTitanEntity;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1259;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;

/**
 * IA e bossbar exclusivamente para titas independentes (ovo, /summon e NPC).
 * Os titas que possuem shifter jogador continuam sob controle do DAOT.
 */
public final class SummerTitanCombat {
    private static final Map<UUID, class_3213> BARS = new ConcurrentHashMap<>();
    private static final double ATTACK_SPEED = 1.05D;

    private SummerTitanCombat() {}

    public static boolean isIndependent(class_1588 titan) {
        if (titan instanceof AttackTitanEntity attack) {
            return attack.getShifterUUID() == null;
        }
        if (titan instanceof ColossalTitanEntity colossal) {
            return colossal.getShifterUUID() == null;
        }
        return false;
    }

    public static class PlayerTargetGoal extends class_1400<class_1657> {
        private final class_1588 titan;

        public PlayerTargetGoal(class_1588 titan) {
            // Os olhos do Colossal ficam muito acima do jogador e a verificacao
            // de linha de visada do ActiveTargetGoal nao o detecta no solo.
            super(titan, class_1657.class, !(titan instanceof ColossalTitanEntity));
            this.titan = titan;
        }

        @Override
        public boolean method_6264() {
            return isIndependent(titan) && super.method_6264();
        }

        @Override
        public boolean method_6266() {
            return isIndependent(titan) && super.method_6266();
        }
    }

    public static class RetaliateGoal extends class_1399 {
        private final class_1588 titan;

        public RetaliateGoal(class_1588 titan) {
            super(titan);
            this.titan = titan;
        }

        @Override
        public boolean method_6264() {
            return isIndependent(titan) && super.method_6264();
        }

        @Override
        public boolean method_6266() {
            return isIndependent(titan) && super.method_6266();
        }
    }

    /** Ativa os ataques e animacoes do proprio DAOT, nunca dano artificial. */
    public static class AssaultGoal extends class_1352 {
        private final class_1588 titan;
        private int colossalAttackCycle;

        public AssaultGoal(class_1588 titan) {
            this.titan = titan;
            method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        }

        private boolean hasTarget() {
            class_1309 target = titan.method_5968();
            return isIndependent(titan) && target != null && target.method_5805()
                    && !target.method_31481() && !titan.method_5987();
        }

        @Override
        public boolean method_6264() {
            return hasTarget();
        }

        @Override
        public boolean method_6266() {
            return hasTarget();
        }

        @Override
        public void method_6268() {
            class_1309 target = titan.method_5968();
            if (target == null) {
                return;
            }
            titan.method_5988().method_6226(target, 30.0f, 30.0f);
            if (titan instanceof ColossalTitanEntity colossal) {
                // A caixa de colisao gigante impede frequentemente a criacao de
                // caminhos pela navegacao terrestre vanilla. Avancamos com
                // velocidade horizontal limitada, mantendo colisao e gravidade.
                pursueColossal(colossal, target);
                // Ataques do proprio DAOT: animacao, efeito e cooldown nativos.
                // Alterna punhos e chute; a classe-base rejeita golpes ocupados.
                if (!colossal.isTransforming() && !colossal.isDefeated()
                        && titan.field_6012 % 40 == 0) {
                    double horizontal = horizontalDistance(titan, target);
                    if (horizontal <= 32.0D) {
                        if (horizontal <= 18.0D && (colossalAttackCycle++ % 3) == 1) {
                            colossal.triggerKickAbility();
                        } else {
                            colossal.triggerAttack();
                        }
                    }
                }
                return;
            }
            if (titan.field_6012 % 10 == 0) {
                titan.method_5942().method_6335(target, ATTACK_SPEED);
            }
            if (titan.method_5858(target) <= 7.0D * 7.0D
                    && titan.field_6012 % 20 == 0
                    && titan instanceof AttackTitanEntity attack && !attack.isDefeated()) {
                attack.triggerAttack();
            }
        }

        private static double horizontalDistance(class_1588 titan, class_1309 target) {
            return Math.hypot(target.method_23317() - titan.method_23317(), target.method_23321() - titan.method_23321());
        }

        private static void pursueColossal(ColossalTitanEntity colossal, class_1309 target) {
            double dx = target.method_23317() - colossal.method_23317();
            double dz = target.method_23321() - colossal.method_23321();
            double distance = Math.hypot(dx, dz);
            if (distance > 0.001D) {
                // Ataques nativos usam o yaw do corpo: olhar apenas com a
                // cabeca pode fazer os punhos golpearem a direcao errada.
                float facing = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
                colossal.method_36456(facing);
                colossal.method_5636(facing);
                colossal.method_5847(facing);
            }
            if (colossal.isTransforming() || colossal.isDefeated()
                    || colossal.isTitanAttacking() || colossal.isKicking()
                    || colossal.isArmDragging() || colossal.isVentingAny()) {
                return;
            }
            if (distance > 16.0D) {
                // addVelocity marca a velocidade como alterada para sincronizacao.
                // Limitamos a velocidade a ~0.20 blocos/tick: movimento pesado.
                class_243 current = colossal.method_18798();
                double intendedX = 0.20D * dx / distance;
                double intendedZ = 0.20D * dz / distance;
                colossal.method_5762(intendedX - current.field_1352, 0.0D,
                        intendedZ - current.field_1350);
            } else {
                // Impede que o Colossal empurre o jogador com movimento continuo.
                class_243 current = colossal.method_18798();
                colossal.method_5762(-current.field_1352, 0.0D, -current.field_1350);
            }
        }

        @Override
        public void method_6270() {
            titan.method_5942().method_6340();
        }
    }

    /** Barra de vida apenas para entidades autonomas; a barra do jogador e do DAOT. */
    public static void tick(class_1588 titan) {
        if (!(titan.method_37908() instanceof class_3218 world)) {
            return;
        }
        if (!isIndependent(titan) || titan.method_31481() || !titan.method_5805()) {
            cleanup(titan);
            return;
        }
        ShifterVariant variant = ShifterVariant.fromTitanType(titan.method_5864());
        if (variant == null) {
            return;
        }
        // Fallback para o Colossal: a selecao vanilla depende de verificacoes
        // de visao e distancia que falham com a altura e largura deste mob.
        if (titan instanceof ColossalTitanEntity && titan.field_6012 % 20 == 0
                && (titan.method_5968() == null || !titan.method_5968().method_5805())) {
            class_1309 nearest = null;
            double bestDistanceSquared = 96.0D * 96.0D;
            for (class_3222 player : world.method_18456()) {
                if (!player.method_5805() || player.method_7325() || player.method_7337()) {
                    continue;
                }
                double distanceSquared = titan.method_5858(player);
                if (distanceSquared < bestDistanceSquared) {
                    bestDistanceSquared = distanceSquared;
                    nearest = player;
                }
            }
            if (nearest != null) {
                titan.method_5980(nearest);
            }
        }
        class_3213 bar = BARS.computeIfAbsent(titan.method_5667(), id ->
                new class_3213(class_2561.method_43470(variant.label + " - Titã"),
                        class_1259.class_1260.field_5784, class_1259.class_1261.field_5795));
        bar.method_5408(class_3532.method_15363(titan.method_6032() / Math.max(1.0f, titan.method_6063()), 0.0f, 1.0f));

        if (titan.field_6012 % 10 != 0) {
            return;
        }
        double radius = variant == ShifterVariant.ARMIN ? 160.0D : 96.0D;
        for (class_3222 player : new ArrayList<>(bar.method_14092())) {
            if (player.method_37908() != world || player.method_5858(titan) > radius * radius
                    || player.method_7325()) {
                bar.method_14089(player);
            }
        }
        for (class_3222 player : world.method_18456()) {
            if (!player.method_7325() && player.method_5858(titan) <= radius * radius) {
                bar.method_14088(player);
            }
        }
    }

    public static void cleanup(class_1588 titan) {
        class_3213 bar = BARS.remove(titan.method_5667());
        if (bar != null) {
            bar.method_14094();
        }
    }
}
