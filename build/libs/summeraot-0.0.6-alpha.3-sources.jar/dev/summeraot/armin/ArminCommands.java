package dev.summeraot.armin;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.summeraot.SummerAOTPower;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

/** Comandos administrativos e de diagnostico. O shift permanece no DAOT nativo. */
public final class ArminCommands {
    private ArminCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            dispatcher.register(class_2170.method_9247("summeraot")
                .then(class_2170.method_9247("armin")
                    .then(class_2170.method_9247("status").executes(ctx -> status(ctx.getSource())))
                    .then(class_2170.method_9247("select").executes(ctx -> select(ctx.getSource())))
                    .then(class_2170.method_9247("grant").requires(src -> src.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> grant(ctx.getSource(), class_2186.method_9315(ctx, "player")))))
                    .then(class_2170.method_9247("revoke").requires(src -> src.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> revoke(ctx.getSource(), class_2186.method_9315(ctx, "player")))))));
            registerDaot(dispatcher);
        });
    }

    private static void registerDaot(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("daot")
            .then(class_2170.method_9247("shifter").requires(src -> src.method_9259(2))
                .then(class_2170.method_9247("set")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("armin").executes(ctx -> {
                            Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
                            int count = 0;
                            for (class_3222 p : targets) if (SummerAOTPower.grantArmin(p)) count++;
                            return count;
                        }))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("armin").executes(ctx -> {
                            Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
                            int count = 0;
                            for (class_3222 p : targets) if (SummerAOTPower.revokeArmin(p)) count++;
                            return count;
                        }))))));
    }

    private static int status(class_2168 source) throws CommandSyntaxException {
        class_3222 p = source.method_9207();
        source.method_9226(() -> class_2561.method_43470("SummerAOT Armin: "
            + (SummerAOTPower.hasArmin(p) ? "concedido" : "nao concedido")
            + ", selecionado=" + SummerAOTPower.isArminSelected(p)), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int select(class_2168 source) throws CommandSyntaxException {
        class_3222 p = source.method_9207();
        if (!SummerAOTPower.hasArmin(p) || !p.method_5805() || p.method_7325() || p.method_5765()) {
            source.method_9213(class_2561.method_43470("Armin indisponivel para selecao."));
            return 0;
        }
        SummerAOTPower.selectArmin(p);
        source.method_9226(() -> class_2561.method_43470("Colossal do Armin selecionado. Use a tecla nativa de transformacao do DAOT."), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int grant(class_2168 source, class_3222 target) {
        boolean changed = SummerAOTPower.grantArmin(target);
        source.method_9226(() -> class_2561.method_43470("Armin " + (changed ? "concedido" : "ja concedido")
            + ": " + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }

    private static int revoke(class_2168 source, class_3222 target) {
        boolean changed = SummerAOTPower.revokeArmin(target);
        source.method_9226(() -> class_2561.method_43470("Armin " + (changed ? "removido" : "nao presente")
            + ": " + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }
}
