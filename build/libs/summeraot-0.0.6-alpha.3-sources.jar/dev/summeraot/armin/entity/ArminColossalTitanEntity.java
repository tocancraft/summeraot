package dev.summeraot.armin.entity;

import daot.ColossalTitanEntity;
import daot.DismountSmokeHelper;
import dev.summeraot.npc.SummerNpcLogic;
import dev.summeraot.npc.SummerTitanCombat;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

/**
 * Versao independente do Titã Colossal do Armin (SpringAOT 3.5.2).
 * Mantem as habilidades / ataques / nuke do Colossal original do DAOT,
 * inclusive a politica nativa de stamina e destransformacao.
 * As hitboxes de nuca, olho e mao sao as mesmas usadas pelo Colossal nativo.
 */
public final class ArminColossalTitanEntity extends ColossalTitanEntity {
    public ArminColossalTitanEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    @Override
    public void onPlayerShift(class_1657 player) {
        super.onPlayerShift(player);
        if (!method_37908().field_9236) {
            // Mesma integracao de fumaça/desmontagem do SpringAOT.
            DismountSmokeHelper.onShifterSpawn(this);
            DismountSmokeHelper.cancelPendingDismount(player.method_5667());
        }
    }

    @Override
    protected void method_5959() {
        // O DAOT deixa os goals vazios para o titan controlado pelo jogador.
        // Estes goals sao automaticamente inativos enquanto houver shifter.
        this.field_6201.method_6277(1, new SummerTitanCombat.AssaultGoal(this));
        this.field_6185.method_6277(1, new SummerTitanCombat.RetaliateGoal(this));
        this.field_6185.method_6277(2, new SummerTitanCombat.PlayerTargetGoal(this));
    }

    @Override
    public void method_5650(net.minecraft.class_1297.class_5529 reason) {
        SummerTitanCombat.cleanup(this);
        super.method_5650(reason);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        SummerNpcLogic.tickNpcTitan(this);
        SummerTitanCombat.tick(this);
    }
}
