package dev.summeraot.armin.client;

import dev.summeraot.armin.entity.ArminColossalTitanEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

/** Modelo, textura e 12 animacoes originais do Armin + arm_drag do DAOT 2.5.0 no SpringAOT 3.5.2. */
public final class ArminColossalTitanModel extends GeoModel<ArminColossalTitanEntity> {
    private static final class_2960 MODEL = class_2960.method_60655("summeraot", "geo/armincolossal.geo.json");
    private static final class_2960 TEXTURE = class_2960.method_60655("summeraot", "textures/entity/armincolossal.png");
    private static final class_2960 ANIMATIONS = class_2960.method_60655("summeraot", "animations/armincolossal.animation.json");

    @Override public class_2960 getModelResource(ArminColossalTitanEntity entity) { return MODEL; }
    @Override public class_2960 getTextureResource(ArminColossalTitanEntity entity) { return TEXTURE; }
    @Override public class_2960 getAnimationResource(ArminColossalTitanEntity entity) { return ANIMATIONS; }
}
