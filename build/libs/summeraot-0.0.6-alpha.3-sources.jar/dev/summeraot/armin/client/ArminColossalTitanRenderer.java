package dev.summeraot.armin.client;

import daot.ColossalTitanEyeEntity;
import daot.ColossalTitanNapeEntity;
import daot.TitanBoneCache;
import daot.network.HitboxBoneSyncPayload;
import dev.summeraot.armin.entity.ArminColossalTitanEntity;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

import java.util.HashMap;
import java.util.Map;

/**
 * Renderer do SpringAOT portado, incluindo hitboxes animadas de nuca e olho.
 * Pacote de sincronizacao ja pertence ao DAOT. Envia no maximo uma vez por tick
 * quando o Armin esta dentro de 64 blocos do jogador local.
 */
public final class ArminColossalTitanRenderer extends GeoEntityRenderer<ArminColossalTitanEntity> {
    private static final Map<Integer, Long> LAST_SEND_TICK = new HashMap<>();

    public ArminColossalTitanRenderer(class_5617.class_5618 context) {
        super(context, new ArminColossalTitanModel());
        this.field_4673 = 4.0f;
    }

    @Override
    public void render(ArminColossalTitanEntity entity, float entityYaw, float tickDelta,
                       class_4587 matrices, class_4597 vertices, int light) {
        super.method_3936(entity, entityYaw, tickDelta, matrices, vertices, light);
        syncHitboxBones(entity, tickDelta);
    }

    private void syncHitboxBones(ArminColossalTitanEntity entity, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (client.field_1724.method_5858(entity) > 4096.0) return;

        long tick = entity.method_37908().method_8510();
        Long last = LAST_SEND_TICK.get(entity.method_5628());
        if (last != null && last == tick) return;
        LAST_SEND_TICK.put(entity.method_5628(), tick);

        GeoBone nape = getGeoModel().getAnimationProcessor().getBone("nape_hitbox");
        GeoBone eye = getGeoModel().getAnimationProcessor().getBone("eye_hitbox");
        if (nape == null && eye == null) return;

        class_243 origin = entity.method_30950(tickDelta);
        float yaw = class_3532.method_16439(tickDelta, entity.field_6220, entity.field_6283);
        double nx = 0, ny = 0, nz = 0, ex = 0, ey = 0, ez = 0;

        if (nape != null) {
            class_243 pos = TitanBoneCache.getAnimatedBoneWorldPos(nape, origin, yaw);
            nx = pos.field_1352; ny = pos.field_1351; nz = pos.field_1350;
            ColossalTitanNapeEntity hitbox = ColossalTitanNapeEntity.getClientInstance(entity.method_5628());
            if (hitbox != null) hitbox.setRendererPosition(nx, ny, nz);
        }
        if (eye != null) {
            class_243 pos = TitanBoneCache.getAnimatedBoneWorldPos(eye, origin, yaw);
            ex = pos.field_1352; ey = pos.field_1351; ez = pos.field_1350;
            ColossalTitanEyeEntity hitbox = ColossalTitanEyeEntity.getClientInstance(entity.method_5628());
            if (hitbox != null) hitbox.setRendererPosition(ex, ey, ez);
        }
        ClientPlayNetworking.send(new HitboxBoneSyncPayload(entity.method_5628(), nx, ny, nz, ex, ey, ez));
    }
}
