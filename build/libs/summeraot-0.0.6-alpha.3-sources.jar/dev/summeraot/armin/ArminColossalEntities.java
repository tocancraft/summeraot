package dev.summeraot.armin;

import daot.ColossalTitanEntity;
import dev.summeraot.armin.entity.ArminColossalTitanEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Entidade nova: preserva os hitboxes nativos da classe ColossalTitanEntity. */
public final class ArminColossalEntities {
    public static final class_1299<ArminColossalTitanEntity> ARMIN_COLOSSAL = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655("summeraot", "armin_colossal_titan"),
        class_1299.class_1300.method_5903(ArminColossalTitanEntity::new, class_1311.field_17715)
            // Exatamente a escala registrada no SpringAOT 3.5.2: 16 x 60 blocos.
            .method_17687(16.0f, 60.0f)
            .method_27299(160) // equivalente a 10 chunks do SpringAOT.
            .method_27300(1)
            .method_5905("summeraot:armin_colossal_titan")
    );

    private ArminColossalEntities() {}

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(ARMIN_COLOSSAL, ColossalTitanEntity.createAttributes());
    }
}
