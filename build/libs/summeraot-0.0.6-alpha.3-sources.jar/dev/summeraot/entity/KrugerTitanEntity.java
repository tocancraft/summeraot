package dev.summeraot.entity;

import daot.AttackTitanEntity;
import dev.summeraot.SummerAOTEntities;
import dev.summeraot.KruggerAbilityPolicy;
import dev.summeraot.npc.SummerNpcLogic;
import dev.summeraot.npc.SummerTitanCombat;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/**
 * Krugger Titan: reutiliza movimentacao e ataques do DAOT, mas nao pode
 * usar endurecimento nem Berserk. A identidade do poder pertence exclusivamente
 * ao SummerAOT; a heranca Java nao concede nem exige o poder attack.
 */
public class KrugerTitanEntity extends AttackTitanEntity {
    public KrugerTitanEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    // ID 6 = Harden; ID 9 = Berserk no SpringAOT 3.5.2.
    // Bloqueia ambas as habilidades mesmo se algum controle externo
    // tentar encaminha-las para a classe AttackTitanEntity do DAOT.
    @Override
    public void triggerAbility(int abilityId) {
        if (!KruggerAbilityPolicy.isAllowedAbility(abilityId)) {
            return;
        }
        super.triggerAbility(abilityId);
    }

    // Protecao adicional contra endurecimento aplicado por outros fluxos,
    // como carregamento de NBT ou chamadas feitas por outros mods.
    @Override
    public void setHardeningMode(int mode) {
        super.setHardeningMode(0);
    }

    // A classe-base usa este estado tanto em combate como para escalar
    // paredes com as maos endurecidas. Krugger nao possui essa habilidade.
    @Override
    public boolean isArmsHardened() {
        return false;
    }

    // DAOT inclui escalada que pode depender de punhos endurecidos.
    // Krugger nao pode entrar nesse estado por controles nem chamadas externas.
    @Override
    public void setTitanClimbing(boolean climbing) {
        super.setTitanClimbing(false);
    }

    @Override
    public boolean isTitanClimbing() {
        return false;
    }

    @Override
    public void spawnHitboxes() {
        if (method_37908().field_9236) {
            return;
        }
        if (napeEntity != null && !napeEntity.method_31481()
                && eyeEntity != null && !eyeEntity.method_31481()
                && grabHitboxEntity != null && !grabHitboxEntity.method_31481()) {
            return;
        }
        discardExistingHitboxes();

        KrugerNapeEntity nape = new KrugerNapeEntity(SummerAOTEntities.KRUGER_NAPE, method_37908());
        KrugerEyeEntity eye = new KrugerEyeEntity(SummerAOTEntities.KRUGER_EYE, method_37908());
        KrugerGrabEntity grab = new KrugerGrabEntity(SummerAOTEntities.KRUGER_GRAB, method_37908());
        nape.setParentTitan(this);
        eye.setParentTitan(this);
        grab.setParentTitan(this);
        nape.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        eye.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        grab.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());

        boolean okNape = method_37908().method_8649(nape);
        boolean okEye = okNape && method_37908().method_8649(eye);
        boolean okGrab = okEye && method_37908().method_8649(grab);
        if (!okGrab) {
            if (okNape) { nape.method_31472(); }
            if (okEye) { eye.method_31472(); }
            return;
        }
        napeEntity = nape;
        eyeEntity = eye;
        grabHitboxEntity = grab;
    }

    private void discardExistingHitboxes() {
        if (napeEntity != null && !napeEntity.method_31481()) { napeEntity.method_31472(); }
        if (eyeEntity != null && !eyeEntity.method_31481()) { eyeEntity.method_31472(); }
        if (grabHitboxEntity != null && !grabHitboxEntity.method_31481()) { grabHitboxEntity.method_31472(); }
        napeEntity = null;
        eyeEntity = null;
        grabHitboxEntity = null;
    }

    @Override
    public void onPlayerShift(class_1657 player) {
        super.onPlayerShift(player);
        if (bossBar != null) {
            String label = player.method_5752().contains("titan_stealth")
                ? "Krugger Titan"
                : player.method_5477().getString() + " - Krugger Titan";
            bossBar.method_5413(class_2561.method_43470(label));
        }
    }

    @Override
    protected void method_5959() {
        // O DAOT deixa os goals vazios para o titan controlado pelo jogador.
        // Estes goals sao automaticamente inativos enquanto houver shifter.
        this.field_6201.method_6277(1, new SummerTitanCombat.AssaultGoal(this));
        this.field_6185.method_6277(1, new SummerTitanCombat.RetaliateGoal(this));
        this.field_6185.method_6277(2, new SummerTitanCombat.PlayerTargetGoal(this));
    }

    @Override
    public void method_5650(net.minecraft.class_1297.class_5529 reason) {
        SummerTitanCombat.cleanup(this);
        super.method_5650(reason);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        SummerNpcLogic.tickNpcTitan(this);
        SummerTitanCombat.tick(this);
    }
}
