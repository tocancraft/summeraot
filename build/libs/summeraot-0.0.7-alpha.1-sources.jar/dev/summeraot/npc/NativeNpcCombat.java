package dev.summeraot.npc;

import daot.ArmoredTitanEntity;
import daot.AttackTitanEntity;
import daot.ColossalTitanEntity;
import daot.FemaleTitanEntity;
import daot.WarhammerTitanEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1259;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** IA e barra apenas dos titas gerados PELOS aldeoes nativos do SummerAOT.
 * Os titas controlados por jogadores e os NPCs vanilla do DAOT nao mudam.
 */
public final class NativeNpcCombat {
    public static final String TAG = "summeraot.native_npc_titan";
    private static final String POWER = "summeraot.native_power.";
    private static final String PROF = "summeraot.native_prof.";
    private static final String LEVEL = "summeraot.native_level.";
    private static final Map<UUID, class_1588> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<UUID, class_3213> BARS = new ConcurrentHashMap<>();

    private NativeNpcCombat() {}

    public static void initialize() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof class_1588 titan && titan.method_5752().contains(TAG)) {
                ACTIVE.put(entity.method_5667(), titan);
            }
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            ACTIVE.remove(entity.method_5667());
            cleanup(entity.method_5667());
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.method_8510() % 5L != 0L) return;
            for (class_1588 titan : new ArrayList<>(ACTIVE.values())) {
                if (titan.method_37908() != world || !titan.method_5752().contains(TAG)) continue;
                if (titan.method_31481() || !titan.method_5805()) {
                    ACTIVE.remove(titan.method_5667());
                    cleanup(titan.method_5667());
                    continue;
                }
                tick(world, titan);
            }
        });
    }

    public static void track(class_1588 titan) {
        if (titan.method_5752().contains(TAG)) ACTIVE.put(titan.method_5667(), titan);
    }

    private static NativeNpcVariant powerOf(class_1588 titan) {
        for (NativeNpcVariant variant : NativeNpcVariant.values()) {
            if (titan.method_5752().contains(POWER + variant.key)) return variant;
        }
        return null;
    }

    private static void tick(class_3218 world, class_1588 titan) {
        NativeNpcVariant variant = powerOf(titan);
        if (variant == null) return;
        if (titan.field_6012 >= 20 * 80 || titan.method_6032() <= 1.0f) {
            restore(world, titan, variant);
            return;
        }

        class_1309 target = titan.method_5968();
        if (target == null || !target.method_5805() || target.method_31481()
                || (target instanceof class_3222 p && (p.method_7337() || p.method_7325()))) {
            target = findTarget(world, titan, variant.isColossal() ? 120.0D : 72.0D);
            titan.method_5980(target);
        }
        if (target != null && !titan.method_5987()) {
            final double dx = target.method_23317() - titan.method_23317();
            final double dz = target.method_23321() - titan.method_23321();
            final double distance = Math.hypot(dx, dz);
            if (distance > 0.01D) {
                float facing = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
                titan.method_36456(facing);
                titan.method_5636(facing);
                titan.method_5847(facing);
            }
            if (variant.isColossal()) {
                if (distance > 22.0D && distance > 0.01D) {
                    class_243 vel = titan.method_18798();
                    titan.method_5762(dx / distance * 0.18D - vel.field_1352, 0.0D,
                            dz / distance * 0.18D - vel.field_1350);
                }
            } else if (distance > 4.0D) {
                titan.method_5942().method_6335(target, 1.05D);
            }
            if (titan.field_6012 % 40 < 5) {
                attack(titan, variant, distance);
            }
        }
        showBossBar(world, titan, variant);
    }

    private static class_1309 findTarget(class_3218 world, class_1588 titan, double radius) {
        class_1309 best = null;
        double bestDist = radius * radius;
        for (class_3222 player : world.method_18456()) {
            if (!player.method_5805() || player.method_7325() || player.method_7337()) continue;
            double dsq = titan.method_5858(player);
            if (dsq < bestDist) {
                best = player;
                bestDist = dsq;
            }
        }
        return best;
    }

    private static void attack(class_1588 titan, NativeNpcVariant variant, double distance) {
        if (titan instanceof ColossalTitanEntity t) {
            if (distance <= 32.0D && !t.isDefeated()) t.triggerAttack();
        } else if (titan instanceof AttackTitanEntity t) {
            if (distance <= 8.0D && !t.isDefeated()) t.triggerAttack();
        } else if (titan instanceof ArmoredTitanEntity t) {
            if (distance <= 8.0D && !t.isDefeated()) t.triggerAttack();
        } else if (titan instanceof FemaleTitanEntity t) {
            if (distance <= 8.0D && !t.isDefeated()) t.triggerAttack();
        } else if (titan instanceof WarhammerTitanEntity t) {
            if (distance <= 12.0D && !t.isDefeated()) t.triggerAttack();
        }
    }

    private static void showBossBar(class_3218 world, class_1588 titan, NativeNpcVariant variant) {
        class_3213 bar = BARS.computeIfAbsent(titan.method_5667(), id ->
                new class_3213(class_2561.method_43470(variant.label + " - NPC"), class_1259.class_1260.field_5784, class_1259.class_1261.field_5795));
        bar.method_5408(class_3532.method_15363(titan.method_6032() / Math.max(1.0f, titan.method_6063()), 0.0f, 1.0f));
        double radius = variant.isColossal() ? 160.0D : 96.0D;
        for (class_3222 player : new ArrayList<>(bar.method_14092())) {
            if (player.method_37908() != world || player.method_7325() || player.method_5858(titan) > radius * radius) {
                bar.method_14089(player);
            }
        }
        for (class_3222 player : world.method_18456()) {
            if (!player.method_7325() && player.method_5858(titan) <= radius * radius) bar.method_14088(player);
        }
    }

    private static String tagValue(class_1297 entity, String prefix) {
        for (String tag : entity.method_5752()) {
            if (tag.startsWith(prefix)) return tag.substring(prefix.length());
        }
        return null;
    }

    private static void restore(class_3218 world, class_1588 titan, NativeNpcVariant variant) {
        NativeShifterVillagerEntity villager = NativeNpcRegistry.newVillager(variant, world);
        if (villager == null) return;
        villager.method_5808(titan.method_23317(), titan.method_23318(), titan.method_23321(), titan.method_36454(), 0.0f);
        String profession = tagValue(titan, PROF);
        if (profession != null) {
            class_2960 id = class_2960.method_12829(profession);
            if (id != null && class_7923.field_41195.method_10250(id)) {
                villager.method_7195(villager.method_7231().method_16921(class_7923.field_41195.method_10223(id)));
            }
        }
        String level = tagValue(titan, LEVEL);
        if (level != null) {
            try {
                int lv = Integer.parseInt(level);
                villager.method_7195(villager.method_7231().method_16920(Math.max(1, Math.min(5, lv))));
            } catch (NumberFormatException ignored) {}
        }
        if (world.method_8649(villager)) {
            ACTIVE.remove(titan.method_5667());
            cleanup(titan.method_5667());
            titan.method_31472();
        }
    }

    private static void cleanup(UUID uuid) {
        class_3213 bar = BARS.remove(uuid);
        if (bar != null) bar.method_14094();
    }
}
