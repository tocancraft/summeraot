package dev.summeraot.npc;

import daot.ColossalTitanEntity;
import daot.network.ModNetworking;
import daot.network.TitanSpawnPayload;
import dev.summeraot.mixin.ColossalNukeAccessor;
import dev.summeraot.mixin.ModNetworkingExplosionInvoker;
import dev.summeraot.network.NpcColossalShiftS2CPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1588;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Replica os efeitos de entrada em forma titanica dos jogadores DAOT.
 * Executar EXATAMENTE uma vez, depois da entidade nascer e o aldeao sair.
 */
public final class SummerNpcShiftEffects {
    private SummerNpcShiftEffects() {}

    public static void onNpcShift(class_3218 world, class_1588 titan, ShifterVariant variant) {
        onNpcShift(world, titan, variant == ShifterVariant.ARMIN,
                variant == ShifterVariant.ARMIN ? TitanSpawnPayload.TYPE_COLOSSAL : TitanSpawnPayload.TYPE_ATTACK);
    }

    /** Mantem os IDs do evento de surgimento correspondentes aos titas originais. */
    public static void onNpcShift(class_3218 world, class_1588 titan, NativeNpcVariant variant) {
        int type = switch (variant) {
            case COLOSSAL -> TitanSpawnPayload.TYPE_COLOSSAL;
            case ARMORED -> TitanSpawnPayload.TYPE_ARMORED;
            case FEMALE -> TitanSpawnPayload.TYPE_FEMALE;
            case WARHAMMER -> TitanSpawnPayload.TYPE_WARHAMMER;
            case ATTACK, JAW, CART -> TitanSpawnPayload.TYPE_ATTACK;
        };
        onNpcShift(world, titan, variant.isColossal(), type);
    }

    private static void onNpcShift(class_3218 world, class_1588 titan, boolean colossal, int type) {
        double x = titan.method_23317();
        double y = titan.method_23318();
        double z = titan.method_23321();

        // Mesmo raio cinematografico do DAOT, agora no instante da transformacao.
        ModNetworking.spawnShiftLightning(world, x, y, z);

        // O DAOT envia esse payload quando o jogador se transforma. O cliente
        // reproduz som com atraso conforme a distancia e particulas de shift.
        TitanSpawnPayload event = new TitanSpawnPayload(x, y, z, titan.method_5628(), type);
        for (class_3222 player : world.method_18456()) {
            if (player.method_5649(x, y, z) <= 512.0D * 512.0D) {
                ServerPlayNetworking.send(player, event);
                if (colossal) {
                    ServerPlayNetworking.send(player,
                            new NpcColossalShiftS2CPayload(x, y, z));
                }
            }
        }

        // Exatamente a onda de dano/repulsao usada no spawnAttack/Colossal.
        // O argumento player e opcional na rotina nativa (null = sem dono).
        ModNetworkingExplosionInvoker.summeraot$triggerExplosion(world, x, y, z,
                null, colossal ? 20.0D : 10.0D, colossal ? 30.0F : 20.0F,
                colossal ? 3.0D : 2.0D);

        // Explosao visual inicial para todos (nao usa createExplosion:
        // a onda de dano ja foi aplicada pelo metodo nativo acima).
        world.method_14199(class_2398.field_11221, x, y + 1.5D, z,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.method_14199(class_2398.field_11204, x, y + 2.0D, z,
                colossal ? 95 : 40, colossal ? 12.0D : 5.0D,
                colossal ? 9.0D : 3.0D, colossal ? 12.0D : 5.0D, 0.05D);
        if (colossal && titan instanceof ColossalTitanEntity) {
            // A sequencia explosiva colossal (20 fases, escombros e fogo) eh
            // implementada pelo proprio DAOT no tick, sem chamar onPlayerShift,
            // que incorretamente tornaria o aldeao um jogador montado.
            ColossalNukeAccessor nuke = (ColossalNukeAccessor) titan;
            nuke.summeraot$setExplosionCenterX(x);
            nuke.summeraot$setExplosionCenterY(y);
            nuke.summeraot$setExplosionCenterZ(z);
            nuke.summeraot$setNukeDebrisSpawned(0);
            nuke.summeraot$setExplosionPhase(1);
        }
    }
}
