package dev.summeraot.npc;

import daot.ArmoredTitanEntity;
import daot.AttackTitanEntity;
import daot.ColossalTitanEntity;
import daot.FemaleTitanEntity;
import daot.WarhammerTitanEntity;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

/** Transforma o aldeao no tipo ORIGINAL do DAOT, nao numa copia do titã. */
public final class NativeNpcTransform {
    private NativeNpcTransform() {}

    public static void complete(NativeShifterVillagerEntity human, NativeNpcVariant variant,
                                class_3218 world, UUID attackerId) {
        if (!human.method_5805() || human.method_31481()) return;
        class_1588 titan = variant.titanType().method_5883(world);
        if (titan == null) return;
        titan.method_5808(human.method_23317(), human.method_23318(), human.method_23321(), human.method_36454(), 0.0f);
        titan.method_5665(class_2561.method_43470(variant.label + " (aldeão shifter)"));
        titan.method_5880(true);
        titan.method_5977(false);
        titan.method_5780(NativeNpcCombat.TAG);
        titan.method_5780("summeraot.native_power." + variant.key);
        titan.method_5780("summeraot.native_prof." +
                class_7923.field_41195.method_10221(human.method_7231().method_16924()));
        titan.method_5780("summeraot.native_level." + human.method_7231().method_16925());
        if (attackerId != null) {
            class_1297 attacker = world.method_14190(attackerId);
            if (attacker instanceof class_1309 living && living.method_5805()) {
                titan.method_5980(living);
            }
        }
        if (titan instanceof AttackTitanEntity t) t.setTransformationTicks(80);
        else if (titan instanceof ColossalTitanEntity t) t.setTransformationTicks(80);
        else if (titan instanceof ArmoredTitanEntity t) t.setTransformationTicks(80);
        else if (titan instanceof FemaleTitanEntity t) t.setTransformationTicks(80);
        else if (titan instanceof WarhammerTitanEntity t) t.setTransformationTicks(80);
        if (!world.method_8649(titan)) return;
        if (titan instanceof AttackTitanEntity t) t.spawnHitboxes();
        else if (titan instanceof ColossalTitanEntity t) t.spawnHitboxes();
        else if (titan instanceof ArmoredTitanEntity t) t.spawnHitboxes();
        else if (titan instanceof FemaleTitanEntity t) t.spawnHitboxes();
        else if (titan instanceof WarhammerTitanEntity t) t.spawnHitboxes();
        human.method_31472();
        NativeNpcCombat.track(titan);
        SummerNpcShiftEffects.onNpcShift(world, titan, variant);
    }
}
