package dev.summeraot.npc;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import java.util.EnumMap;
import java.util.Map;

/** Novo conjunto de ovos; NAO sobrescreve entidades nem itens do Danny's AOT. */
public final class NativeNpcRegistry {
    private static final Map<NativeNpcVariant, class_1299<NativeShifterVillagerEntity>> VILLAGERS = new EnumMap<>(NativeNpcVariant.class);
    private static final Map<NativeNpcVariant, class_1792> VILLAGER_EGGS = new EnumMap<>(NativeNpcVariant.class);
    private static final Map<NativeNpcVariant, class_1792> TITAN_EGGS = new EnumMap<>(NativeNpcVariant.class);

    private NativeNpcRegistry() {}

    private static class_1792 registerItem(String id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("summeraot", id), item);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static class_1792 egg(String name, class_1299<?> type, int base, int spots) {
        return registerItem(name, new class_1826((class_1299) type, base, spots, new class_1792.class_1793()));
    }

    public static class_1299<NativeShifterVillagerEntity> villagerType(NativeNpcVariant variant) {
        return VILLAGERS.get(variant);
    }

    public static NativeShifterVillagerEntity newVillager(NativeNpcVariant variant, class_3218 world) {
        class_1299<NativeShifterVillagerEntity> type = villagerType(variant);
        return type == null ? null : type.method_5883(world);
    }

    public static void initialize() {
        for (NativeNpcVariant variant : NativeNpcVariant.values()) {
            String id = variant.villagerId();
            class_1299<NativeShifterVillagerEntity> type = class_2378.method_10230(
                    class_7923.field_41177, class_2960.method_60655("summeraot", id),
                    class_1299.class_1300.method_5903(NativeShifterVillagerEntity::new, class_1311.field_17715)
                            .method_17687(0.6f, 1.95f).method_55687(1.62f)
                            .method_27299(10).method_27300(3)
                            .method_5905("summeraot:" + id));
            VILLAGERS.put(variant, type);
            FabricDefaultAttributeRegistry.register(type, class_1646.method_26955());
            VILLAGER_EGGS.put(variant, egg(variant.villagerEggId(), type,
                    variant.primaryColor, variant.secondaryColor));
            TITAN_EGGS.put(variant, egg(variant.titanEggId(), variant.titanType(),
                    variant.secondaryColor, variant.primaryColor));
        }
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            for (NativeNpcVariant variant : NativeNpcVariant.values()) {
                entries.method_45421(VILLAGER_EGGS.get(variant));
                entries.method_45421(TITAN_EGGS.get(variant));
            }
        });
    }
}
