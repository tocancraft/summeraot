package dev.summeraot.npc;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_3218;

/** Aldeao funcional com skin humana, profissao e comportamento vanilla. */
public final class NativeShifterVillagerEntity extends class_1646 {
    private int pendingShiftTicks;
    private java.util.UUID lastAttacker;

    public NativeShifterVillagerEntity(class_1299<? extends class_1646> type, class_1937 world) {
        super(type, world);
    }

    public NativeNpcVariant variant() {
        return NativeNpcVariant.byVillagerType(method_5864());
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (!method_37908().field_9236 && method_37908() instanceof class_3218
                && amount > 0.0f && variant() != null) {
            if (pendingShiftTicks > 0) return false;
            float remaining = method_6032() - amount;
            if (remaining <= Math.max(1.0f, method_6063() * 0.70f)) {
                pendingShiftTicks = 40;
                lastAttacker = source.method_5529() instanceof class_1309 living ? living.method_5667() : null;
                method_6033(Math.max(1.0f, remaining));
                return false;
            }
        }
        return super.method_5643(source, amount);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        NativeNpcVariant variant = variant();
        if (variant == null) return;
        if (method_37908().field_9236 && method_5805()) {
            class_2390 dust = new class_2390(variant.particleColor(), 1.0f);
            for (int i = 0; i < 4; i++) {
                double dx = (field_5974.method_43058() - 0.5D) * 0.8D;
                double dy = (field_5974.method_43058() - 0.5D) * 1.2D;
                double dz = (field_5974.method_43058() - 0.5D) * 0.8D;
                method_37908().method_8406(dust, method_23317() + dx,
                        method_23318() + method_17682() * 0.5D + dy, method_23321() + dz,
                        0.0D, 0.02D, 0.0D);
            }
        }
        if (pendingShiftTicks > 0 && method_37908() instanceof class_3218 world) {
            if (--pendingShiftTicks == 0) {
                NativeNpcTransform.complete(this, variant, world, lastAttacker);
            }
        }
    }
}
