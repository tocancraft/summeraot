package dev.summeraot.npc;

import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_927;

/** UV de jogador: as imagens de 64x64 nao usam UV de aldeao vanilla. */
public final class NativeNpcRenderer extends class_927<NativeShifterVillagerEntity, class_591<NativeShifterVillagerEntity>> {
    private final class_2960 texture;

    public NativeNpcRenderer(class_5617.class_5618 context, NativeNpcVariant variant) {
        super(context, new class_591<>(context.method_32167(class_5602.field_27577), false), 0.5f);
        texture = variant.skin();
    }

    @Override
    public class_2960 getTexture(NativeShifterVillagerEntity entity) {
        return texture;
    }
}
