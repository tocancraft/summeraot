package dev.summeraot.client;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Hotbar exclusiva do Krugger. Sem endurecimento de nuca, endurecimento das
 * maos, Berserk ou icones herdados que nao correspondam ao seu repertorio.
 *
 * IDs preservados do DAOT: 1=pisao, 2=chute, 3=defesa, 7=agarrar.
 * Nenhuma tecla e capturada: continua usando os controles do DAOT.
 */
public final class KruggerAbilityHud {
    private static final class_2960 SLOT = class_2960.method_60655("dannys-aot", "textures/gui/abilities_slot_unselected.png");
    private static final class_2960 STOMP = class_2960.method_60655("dannys-aot", "textures/gui/ability_titan_ground_stomp.png");
    private static final class_2960 KICK = class_2960.method_60655("dannys-aot", "textures/gui/ability_titan_kickback.png");
    private static final class_2960 GRAB = class_2960.method_60655("dannys-aot", "textures/gui/ability_titan_grab_female.png");

    private record Action(String key, String label, class_2960 icon) {}
    private static final Action[] ACTIONS = {
        new Action("1", "PISÃO", STOMP),
        new Action("2", "CHUTE", KICK),
        new Action("3", "DEFESA", null),
        new Action("7", "AGARRAR", GRAB)
    };

    private KruggerAbilityHud() {}

    public static void render(class_332 context) {
        class_310 client = class_310.method_1551();
        int spacing = 28;
        int startX = (context.method_51421() - (ACTIONS.length - 1) * spacing - 22) / 2;
        int y = context.method_51443() - 26;

        for (int i = 0; i < ACTIONS.length; i++) {
            Action action = ACTIONS[i];
            int x = startX + i * spacing;
            context.method_25293(SLOT, x, y, 22, 22, 0f, 0f, 48, 46, 48, 46);
            if (action.icon != null) {
                context.method_25293(action.icon, x + 3, y + 3, 16, 16, 0f, 0f, 32, 32, 32, 32);
            } else {
                context.method_25300(client.field_1772, "DEF", x + 11, y + 7, 0xFFFFFF);
            }
            context.method_25300(client.field_1772, action.key, x + 11, y - 11, 0xFFFFFF);
        }
    }
}
