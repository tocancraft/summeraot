package dev.summeraot;

import daot.AttackTitanEntity;
import daot.AttackTitanEyeEntity;
import daot.AttackTitanGrabEntity;
import daot.AttackTitanNapeEntity;
import dev.summeraot.entity.KrugerEyeEntity;
import dev.summeraot.entity.KrugerGrabEntity;
import dev.summeraot.entity.KrugerNapeEntity;
import dev.summeraot.entity.KrugerTitanEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class SummerAOTEntities {
    private SummerAOTEntities() {}

    // Dimensões extraídas de SpringDAOTEntities (3x15, 1x1, 1x1, 2x2).
    public static final class_1299<KrugerTitanEntity> KRUGER = class_2378.method_10230(
        class_7923.field_41177, class_2960.method_60655(SummerAOTMod.MOD_ID, "krugger_titan"),
        class_1299.class_1300.method_5903(KrugerTitanEntity::new, class_1311.field_17715)
            .method_17687(3.0f, 15.0f).method_55687(14.0f)
            .method_27299(160).method_27300(1)
            .method_5905("summeraot:krugger_titan")
    );
    public static final class_1299<KrugerNapeEntity> KRUGER_NAPE = class_2378.method_10230(
        class_7923.field_41177, class_2960.method_60655(SummerAOTMod.MOD_ID, "krugger_titan_nape"),
        class_1299.class_1300.method_5903(KrugerNapeEntity::new, class_1311.field_17715)
            .method_17687(1.0f, 1.0f).method_27299(160).method_27300(1)
            .method_5905("summeraot:krugger_titan_nape")
    );
    public static final class_1299<KrugerEyeEntity> KRUGER_EYE = class_2378.method_10230(
        class_7923.field_41177, class_2960.method_60655(SummerAOTMod.MOD_ID, "krugger_titan_eye"),
        class_1299.class_1300.method_5903(KrugerEyeEntity::new, class_1311.field_17715)
            .method_17687(1.0f, 1.0f).method_27299(160).method_27300(1)
            .method_5905("summeraot:krugger_titan_eye")
    );
    public static final class_1299<KrugerGrabEntity> KRUGER_GRAB = class_2378.method_10230(
        class_7923.field_41177, class_2960.method_60655(SummerAOTMod.MOD_ID, "krugger_titan_grab"),
        class_1299.class_1300.method_5903(KrugerGrabEntity::new, class_1311.field_17715)
            .method_17687(2.0f, 2.0f).method_27299(160).method_27300(1)
            .method_5905("summeraot:krugger_titan_grab")
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(KRUGER, AttackTitanEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(KRUGER_NAPE, AttackTitanNapeEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(KRUGER_EYE, AttackTitanEyeEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(KRUGER_GRAB, AttackTitanGrabEntity.createAttributes());
    }
}
