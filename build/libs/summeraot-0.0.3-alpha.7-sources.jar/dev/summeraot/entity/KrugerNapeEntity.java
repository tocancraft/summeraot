package dev.summeraot.entity;

import daot.AttackTitanNapeEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1937;

/** Usa dano, posição, persistência e interação da hitbox já mantida pelo DAOT. */
public final class KrugerNapeEntity extends AttackTitanNapeEntity {
    public KrugerNapeEntity(class_1299<? extends class_1308> type, class_1937 world) {
        super(type, world);
    }
}
