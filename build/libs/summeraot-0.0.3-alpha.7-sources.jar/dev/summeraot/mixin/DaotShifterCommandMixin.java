package dev.summeraot.mixin;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import dev.summeraot.SummerAOTMod;
import dev.summeraot.SummerAOTPower;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Acrescenta uma opcao REAL na arvore Brigadier do /daot, incluindo Tab.
 *
 * O DAOT define /daot shifter set/remove <targets> <type> e uma lista
 * fixa de sugestoes. Injetar somente em setShifter/removeShifter nao
 * acrescenta "krugger" ao autocompletar; criar um literal como irmao
 * do argumento <type> corrige isso sem alterar o registro de poderes
 * originais do Danny's AoT.
 *
 * A arvore e estendida ao final do registro original. Preserva as
 * verificacoes de permissao do no /daot shifter e nao concede 'attack'.
 */
@Mixin(targets = "daot.ModCommands", remap = false)
public abstract class DaotShifterCommandMixin {

    @Inject(method = "register", at = @At("TAIL"), remap = false)
    private static void summeraot$registerKruggerInDaot(
            CommandDispatcher<class_2168> dispatcher, CallbackInfo ci) {

        CommandNode<class_2168> daot = dispatcher.getRoot().getChild("daot");
        CommandNode<class_2168> shifter = child(daot, "shifter");
        CommandNode<class_2168> setTargets = child(child(shifter, "set"), "targets");
        CommandNode<class_2168> removeTargets = child(child(shifter, "remove"), "targets");

        if (setTargets == null || removeTargets == null) {
            SummerAOTMod.LOGGER.error(
                    "SummerAOT: estrutura /daot shifter alterada; nao foi possivel registrar krugger.");
            return;
        }

        if (setTargets.getChild("krugger") == null) {
            setTargets.addChild(class_2170.method_9247("krugger")
                    .executes(DaotShifterCommandMixin::grant)
                    .build());
        }
        if (removeTargets.getChild("krugger") == null) {
            removeTargets.addChild(class_2170.method_9247("krugger")
                    .executes(DaotShifterCommandMixin::revoke)
                    .build());
        }

        SummerAOTMod.LOGGER.info(
                "SummerAOT: krugger registrado em /daot shifter set/remove (com autocompletar).");
    }

    private static CommandNode<class_2168> child(
            CommandNode<class_2168> parent, String name) {
        return parent == null ? null : parent.getChild(name);
    }

    private static int grant(CommandContext<class_2168> context)
            throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(context, "targets");
        int changed = 0;
        for (class_3222 player : targets) {
            if (SummerAOTPower.grantKrugger(player)) {
                changed++;
            }
        }
        int result = changed;
        context.getSource().method_9226(() -> class_2561.method_43470(
                "SummerAOT: Krugger Titan concedido a " + result + " jogador(es)."), true);
        return changed;
    }

    private static int revoke(CommandContext<class_2168> context)
            throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(context, "targets");
        int changed = 0;
        for (class_3222 player : targets) {
            if (SummerAOTPower.revokeKrugger(player)) {
                changed++;
            }
        }
        int result = changed;
        context.getSource().method_9226(() -> class_2561.method_43470(
                "SummerAOT: Krugger Titan removido de " + result + " jogador(es)."), true);
        return changed;
    }
}
