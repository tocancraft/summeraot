package dev.summeraot.mixin;

import dev.summeraot.client.KruggerAbilityHud;
import dev.summeraot.entity.KrugerTitanEntity;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * O DAOT renderiza a barra Attack para TODAS as subclasses de AttackTitanEntity.
 * Quando a montaria e o Krugger, substituimos a barra original, em vez de
 * somente bloquear as habilidades (o que deixaria icones incorretos visiveis).
 *
 * Ponto de injecao conferido no DAOT fornecido (jar com Loom 1.14.10).
 */
@Mixin(targets = "daot.ShifterAbilityHUD", remap = false)
public abstract class KruggerHudMixin {
    @Inject(
        method = "lambda$register$0(Lnet/minecraft/class_332;Lnet/minecraft/class_9779;)V",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private static void summeraot$drawOwnHud(class_332 context, class_9779 tickCounter,
                                             CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || !(client.field_1724.method_5854() instanceof KrugerTitanEntity krugger)) {
            return;
        }
        ci.cancel();
        if (!client.field_1690.field_1842 && !krugger.isDismounting()) {
            KruggerAbilityHud.render(context);
        }
    }
}
