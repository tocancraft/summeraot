package dev.summeraot.client;

import daot.AttackTitanEyeRenderer;
import daot.AttackTitanGrabRenderer;
import daot.AttackTitanNapeRenderer;
import dev.summeraot.SummerAOTEntities;
import dev.summeraot.grisha.GrishaEntities;
import dev.summeraot.grisha.client.GrishaTitanRenderer;
import dev.summeraot.grisha.entity.GrishaNapeEntity;
import dev.summeraot.grisha.entity.GrishaEyeEntity;
import dev.summeraot.grisha.entity.GrishaGrabEntity;
import dev.summeraot.entity.KrugerEyeEntity;
import dev.summeraot.entity.KrugerGrabEntity;
import dev.summeraot.entity.KrugerNapeEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_897;

/**
 * Renderizadores das hitboxes do Danny operam sobre as nossas subclasses.
 * A conversão de generics é necessária porque a API registra o tipo exato.
 */
@SuppressWarnings("unchecked")
public final class SummerAOTClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        OmniKruggerClientState.register();
        OmniKruggerScreenBridge.register();
        EntityRendererRegistry.register(SummerAOTEntities.KRUGER, KrugerTitanRenderer::new);
        EntityRendererRegistry.register(GrishaEntities.GRISHA_TITAN, GrishaTitanRenderer::new);
        EntityRendererRegistry.register(GrishaEntities.GRISHA_NAPE,
            context -> (class_897<GrishaNapeEntity>)(class_897<?>) new AttackTitanNapeRenderer(context));
        EntityRendererRegistry.register(GrishaEntities.GRISHA_EYE,
            context -> (class_897<GrishaEyeEntity>)(class_897<?>) new AttackTitanEyeRenderer(context));
        EntityRendererRegistry.register(GrishaEntities.GRISHA_GRAB,
            context -> (class_897<GrishaGrabEntity>)(class_897<?>) new AttackTitanGrabRenderer(context));
        EntityRendererRegistry.register(SummerAOTEntities.KRUGER_NAPE,
            context -> (class_897<KrugerNapeEntity>)(class_897<?>) new AttackTitanNapeRenderer(context));
        EntityRendererRegistry.register(SummerAOTEntities.KRUGER_EYE,
            context -> (class_897<KrugerEyeEntity>)(class_897<?>) new AttackTitanEyeRenderer(context));
        EntityRendererRegistry.register(SummerAOTEntities.KRUGER_GRAB,
            context -> (class_897<KrugerGrabEntity>)(class_897<?>) new AttackTitanGrabRenderer(context));
    }
}
