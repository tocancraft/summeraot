package dev.summeraot.mixin;

import daot.PowerAuthority;
import daot.AttackTitanEntity;
import daot.TitanPowerType;
import daot.network.ModNetworking;
import dev.summeraot.SummerAOTEntities;
import dev.summeraot.grisha.GrishaEntities;
import dev.summeraot.grisha.entity.GrishaTitanEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import dev.summeraot.SummerAOTMod;
import dev.summeraot.SummerAOTPower;
import dev.summeraot.entity.KrugerTitanEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Liga o poder independente do SummerAOT ao fluxo NATIVO de transformacao
 * do DAOT sem conceder, falsificar ou modificar a tag "attack" do jogador.
 *
 * O DAOT tem um enum fechado de oito tipos, portanto o ATTACK e usado
 * somente como canal interno de despacho da animacao / stamina.
 * A entidade criada e o poder persistido continuam sendo KRUGGER ou GRISHA.
 *
 * Referencia estrutural: implementacao de ModNetworkingMixin do
 * SpringAOT 3.5.2, adaptada para os poderes independentes do SummerAOT.
 */
@Mixin(value = ModNetworking.class, remap = false)
public abstract class KruggerNetworkingMixin {

    /**
     * O DAOT consulta PowerAuthority.hasShifter(ATTACK) durante o Shift.
     * A resposta local a essa consulta aceita Krugger ou Grisha, sem alterar
     * TitanPowerData nem atribuir o poder Attack ao jogador.
     * Para todos os outros tipos e jogadores, a regra original e preservada.
     */
    @Redirect(
        method = {"handleTitanShift", "handleTeaseShift"},
        at = @At(
            value = "INVOKE",
            target = "Ldaot/PowerAuthority;hasShifter(Lnet/minecraft/entity/player/PlayerEntity;Ldaot/TitanPowerType;)Z"
        )
    )
    private static boolean summeraot$recognizeKruggerPower(class_1657 player, TitanPowerType type) {
        if (type == TitanPowerType.ATTACK && player instanceof class_3222 serverPlayer
                && (SummerAOTPower.isKruggerSelected(serverPlayer)
                    || SummerAOTPower.isGrishaSelected(serverPlayer))) {
            return true;
        }
        return PowerAuthority.hasShifter(player, type);
    }

    /**
     * O DAOT ja executou suas verificacoes, consumo de stamina e a fase
     * de transformacao. No instante em que criaria seu Attack Titan,
     * o SummerAOT cria a entidade propria do poder selecionado.
     */
    @Inject(method = "spawnAttackTitan", at = @At("HEAD"), cancellable = true)
    private static void summeraot$spawnKrugger(
            class_3222 player,
            class_3218 world,
            double x,
            double y,
            double z,
            float yaw,
            CallbackInfo ci) {
        boolean grishaSelected = SummerAOTPower.isGrishaSelected(player);
        if (!SummerAOTPower.isKruggerSelected(player) && !grishaSelected) {
            return;
        }
        ci.cancel();

        if (!player.method_5805() || player.method_7325()) {
            return;
        }
        if (player.method_5854() instanceof KrugerTitanEntity
                || player.method_5854() instanceof GrishaTitanEntity) {
            return;
        }

        AttackTitanEntity titan = grishaSelected
                ? GrishaEntities.GRISHA_TITAN.method_5883(world)
                : SummerAOTEntities.KRUGER.method_5883(world);
        if (titan == null) {
            player.method_7353(class_2561.method_43470("SummerAOT: nao foi possivel criar o tita selecionado."), false);
            SummerAOTMod.LOGGER.error("SummerAOT: falha na criacao de tita para {}", player.method_5477().getString());
            return;
        }

        // Reaproveita a preparacao do titan do Spring/DAOT; a habilidade
        // de endurecimento e Berserk permanecem bloqueadas na entidade.
        titan.method_5808(x, y, z, yaw, player.method_36455());
        titan.method_5636(yaw);
        titan.method_5847(yaw);
        titan.setTransformationTicks(80);
        titan.method_5875(true);
        titan.setShifterUUID(player.method_5667());
        titan.setHardeningMode(0);

        if (!world.method_8649(titan)) {
            player.method_7353(class_2561.method_43470("SummerAOT: falha ao inserir tita no mundo."), false);
            return;
        }
        ModNetworking.spawnShiftLightning(world, x, y, z);
        titan.spawnHitboxes();
        titan.onPlayerShift(player);
        SummerAOTMod.LOGGER.info("SummerAOT: {} transformado em {} Titan pelo fluxo nativo do DAOT",
                player.method_5477().getString(), grishaSelected ? "Grisha" : "Krugger");
    }
}
