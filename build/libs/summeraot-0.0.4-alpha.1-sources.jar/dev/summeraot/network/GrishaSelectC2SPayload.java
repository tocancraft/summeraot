package dev.summeraot.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client request only. Server checks possession and cooldown. */
public record GrishaSelectC2SPayload() implements class_8710 {
    public static final class_9154<GrishaSelectC2SPayload> ID =
        new class_9154<>(class_2960.method_60655("summeraot", "select_grisha"));
    public static final class_9139<class_9129, GrishaSelectC2SPayload> CODEC =
        class_9139.method_56438((packet, buf) -> {}, buf -> new GrishaSelectC2SPayload());
    @Override public class_9154<? extends class_8710> method_56479() { return ID; }
}
