package dev.summeraot.grisha;

import net.minecraft.class_2960;

/**
 * Pontos de integracao com o seletor/persistencia ja existentes no SummerAOT.
 * Esta classe define as chaves; o codigo de selecao do Alpha 7 deve usa-las.
 */
public final class GrishaPowerIds {
    public static final String POWER_TAG = "grisha";
    public static final boolean ALLOW_HARDENING = false;
    public static final boolean ALLOW_BERSERKER = false;
    public static final class_2960 POWER_ID = class_2960.method_60655("summeraot", "grisha");
    public static final class_2960 SELECT_CHANNEL = class_2960.method_60655("summeraot", "select_grisha");
    public static final class_2960 TITAN_ENTITY = class_2960.method_60655("summeraot", "grisha_titan");

    private GrishaPowerIds() {}
}
