package dev.summeraot.grisha.client;

import daot.AttackTitanEyeEntity;
import daot.AttackTitanGrabEntity;
import daot.AttackTitanNapeEntity;
import daot.TitanBoneCache;
import dev.summeraot.grisha.entity.GrishaTitanEntity;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Renderiza o modelo Spring. Reposiciona hitboxes no CLIENTE pelos bones,
 * usando a API de cache e as hitboxes que já existem no DAOT.
 * No servidor, o DAOT continua sendo responsável por fallback de posição.
 * A sincronização por pacote Spring ainda não foi portada nesta versão.
 */
public final class GrishaTitanRenderer extends GeoEntityRenderer<GrishaTitanEntity> {
    public GrishaTitanRenderer(class_5617.class_5618 context) {
        super(context, new GrishaTitanModel());
        this.field_4673 = 2.0f;
    }

    @Override
    public void render(GrishaTitanEntity entity, float entityYaw, float tickDelta,
                       class_4587 matrices, class_4597 vertexConsumers, int light) {
        super.method_3936(entity, entityYaw, tickDelta, matrices, vertexConsumers, light);
        moveClientHitboxes(entity, tickDelta);
    }

    private void moveClientHitboxes(GrishaTitanEntity entity, float tickDelta) {
        int parent = entity.method_5628();
        class_243 origin = entity.method_30950(tickDelta);
        float yaw = class_3532.method_16439(tickDelta, entity.field_6220, entity.field_6283);
        GeoBone nape = getGeoModel().getAnimationProcessor().getBone("nape_hitbox");
        GeoBone eye = getGeoModel().getAnimationProcessor().getBone("eye_hitbox");
        GeoBone grab = getGeoModel().getAnimationProcessor().getBone("grab_hitbox");
        AttackTitanNapeEntity n = AttackTitanNapeEntity.getClientInstance(parent);
        AttackTitanEyeEntity e = AttackTitanEyeEntity.getClientInstance(parent);
        AttackTitanGrabEntity g = AttackTitanGrabEntity.getClientInstance(parent);
        if (nape != null && n != null) {
            class_243 pos = TitanBoneCache.getAnimatedBoneWorldPos(nape, origin, yaw);
            n.setRendererPosition(pos.field_1352, pos.field_1351, pos.field_1350);
        }
        if (eye != null && e != null) {
            class_243 pos = TitanBoneCache.getAnimatedBoneWorldPos(eye, origin, yaw);
            e.setRendererPosition(pos.field_1352, pos.field_1351, pos.field_1350);
        }
        if (grab != null && g != null) {
            class_243 pos = TitanBoneCache.getAnimatedBoneWorldPos(grab, origin, yaw);
            g.setRendererPosition(pos.field_1352, pos.field_1351, pos.field_1350);
        }
    }
}
