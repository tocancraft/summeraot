package dev.summeraot.grisha.client;

import dev.summeraot.grisha.entity.GrishaTitanEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

/** Os 37 clipes originais de Attack4Titan do SpringAOT. */
public final class GrishaTitanModel extends GeoModel<GrishaTitanEntity> {
    private static final class_2960 MODEL = class_2960.method_60655("summeraot", "geo/attack4titan.geo.json");
    private static final class_2960 TEXTURE = class_2960.method_60655("summeraot", "textures/entity/attack4titan.png");
    private static final class_2960 ANIMATIONS = class_2960.method_60655("summeraot", "animations/attack4titan.animation.json");

    @Override
    public class_2960 getModelResource(GrishaTitanEntity entity) {
        return MODEL;
    }

    @Override
    public class_2960 getTextureResource(GrishaTitanEntity entity) {
        return TEXTURE;
    }

    @Override
    public class_2960 getAnimationResource(GrishaTitanEntity entity) {
        return ANIMATIONS;
    }
}
