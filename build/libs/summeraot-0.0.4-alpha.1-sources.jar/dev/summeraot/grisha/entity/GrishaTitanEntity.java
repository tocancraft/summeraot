package dev.summeraot.grisha.entity;

import daot.AttackTitanEntity;
import dev.summeraot.grisha.GrishaEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/**
 * O Grisha eh um shifter novo, independente do Attack e do Krugger.
 * Herda os ataques normais do AttackTitanEntity do DAOT 2.5.0.
 * Sem endurecimento (habilidade 6), escalada endurecida ou modo Berserker.
 */
public final class GrishaTitanEntity extends AttackTitanEntity {
    // IDs da política Krugger/Spring: 6=endurecimento, 9=Berserker.
    private static final int ABILITY_HARDENING = 6;
    private static final int ABILITY_BERSERKER = 9;

    public GrishaTitanEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    @Override
    public void triggerAbility(int ability) {
        if (ability == ABILITY_HARDENING || ability == ABILITY_BERSERKER) {
            return;
        }
        super.triggerAbility(ability);
    }

    @Override
    public void setHardeningMode(int hardeningMode) {
        // Inclui restauracao de NBT e comandos externos; sempre desabilitado.
        super.setHardeningMode(0);
    }

    @Override
    public boolean isArmsHardened() {
        return false;
    }

    @Override
    public void setTitanClimbing(boolean climbing) {
        // No DAOT a escalada exige ativacao do endurecimento.
        super.setTitanClimbing(false);
    }

    @Override
    public boolean isTitanClimbing() {
        return false;
    }

    @Override
    public void onPlayerShift(class_1657 player) {
        super.onPlayerShift(player);
        if (bossBar != null) {
            String label = player.method_5752().contains("titan_stealth")
                ? "Grisha Titan" : player.method_5477().getString() + " - Grisha Titan";
            bossBar.method_5413(class_2561.method_43470(label));
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (getHardeningMode() != 0) {
            super.setHardeningMode(0);
        }
        if (isTitanClimbing()) {
            super.setTitanClimbing(false);
        }
    }

    @Override
    public void spawnHitboxes() {
        if (method_37908().field_9236) {
            return;
        }
        if (napeEntity != null && napeEntity.method_5805()
            && eyeEntity != null && eyeEntity.method_5805()
            && grabHitboxEntity != null && grabHitboxEntity.method_5805()) {
            return;
        }

        // Recria um trio inteiro se alguma hitbox foi destruida/descarregada.
        if (napeEntity != null && !napeEntity.method_31481()) {
            napeEntity.method_31472();
        }
        if (eyeEntity != null && !eyeEntity.method_31481()) {
            eyeEntity.method_31472();
        }
        if (grabHitboxEntity != null && !grabHitboxEntity.method_31481()) {
            grabHitboxEntity.method_31472();
        }
        napeEntity = null;
        eyeEntity = null;
        grabHitboxEntity = null;

        GrishaNapeEntity nape = new GrishaNapeEntity(GrishaEntities.GRISHA_NAPE, method_37908());
        GrishaEyeEntity eye = new GrishaEyeEntity(GrishaEntities.GRISHA_EYE, method_37908());
        GrishaGrabEntity grab = new GrishaGrabEntity(GrishaEntities.GRISHA_GRAB, method_37908());

        nape.setParentTitan(this);
        eye.setParentTitan(this);
        grab.setParentTitan(this);

        nape.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        eye.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
        grab.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());

        boolean napeSpawned = method_37908().method_8649(nape);
        boolean eyeSpawned = napeSpawned && method_37908().method_8649(eye);
        boolean grabSpawned = eyeSpawned && method_37908().method_8649(grab);
        if (!grabSpawned) {
            if (napeSpawned) {
                nape.method_31472();
            }
            if (eyeSpawned) {
                eye.method_31472();
            }
            return;
        }
        napeEntity = nape;
        eyeEntity = eye;
        grabHitboxEntity = grab;
    }
}
