package dev.summeraot.grisha.entity;

import daot.AttackTitanNapeEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1937;

/** Hitbox registrada exclusivamente para Grisha Titan. */
public final class GrishaNapeEntity extends AttackTitanNapeEntity {
    public GrishaNapeEntity(class_1299<? extends class_1308> type, class_1937 world) {
        super(type, world);
    }
}
