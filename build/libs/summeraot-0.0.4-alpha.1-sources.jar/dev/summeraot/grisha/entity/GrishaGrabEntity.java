package dev.summeraot.grisha.entity;

import daot.AttackTitanGrabEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1937;

/** Hitbox registrada exclusivamente para Grisha Titan. */
public final class GrishaGrabEntity extends AttackTitanGrabEntity {
    public GrishaGrabEntity(class_1299<? extends class_1308> type, class_1937 world) {
        super(type, world);
    }
}
