package dev.summeraot.grisha;

import daot.AttackTitanEntity;
import daot.AttackTitanNapeEntity;
import daot.AttackTitanEyeEntity;
import daot.AttackTitanGrabEntity;
import dev.summeraot.grisha.entity.GrishaTitanEntity;
import dev.summeraot.grisha.entity.GrishaNapeEntity;
import dev.summeraot.grisha.entity.GrishaEyeEntity;
import dev.summeraot.grisha.entity.GrishaGrabEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Registros exclusivos do Grisha: NUNCA reutilizar o power ID "attack". */
public final class GrishaEntities {
    public static final String POWER_TAG = "grisha";

    public static final class_1299<GrishaTitanEntity> GRISHA_TITAN = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655("summeraot", "grisha_titan"),
        class_1299.class_1300.method_5903(GrishaTitanEntity::new, class_1311.field_17715)
            .method_17687(2.3f, 15.0f)
            .method_55687(14.0f)
            .method_27299(32)
            .method_27300(2)
            .method_5905("summeraot:grisha_titan")
    );

    public static final class_1299<GrishaNapeEntity> GRISHA_NAPE = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655("summeraot", "grisha_titan_nape"),
        class_1299.class_1300.method_5903(GrishaNapeEntity::new, class_1311.field_17715)
            .method_17687(1.5f, 2.0f)
            .method_27299(32)
            .method_27300(2)
            .method_5905("summeraot:grisha_titan_nape")
    );

    public static final class_1299<GrishaEyeEntity> GRISHA_EYE = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655("summeraot", "grisha_titan_eye"),
        class_1299.class_1300.method_5903(GrishaEyeEntity::new, class_1311.field_17715)
            .method_17687(1.5f, 1.2f)
            .method_27299(32)
            .method_27300(2)
            .method_5905("summeraot:grisha_titan_eye")
    );

    public static final class_1299<GrishaGrabEntity> GRISHA_GRAB = class_2378.method_10230(
        class_7923.field_41177,
        class_2960.method_60655("summeraot", "grisha_titan_grab"),
        class_1299.class_1300.method_5903(GrishaGrabEntity::new, class_1311.field_17715)
            .method_17687(1.5f, 2.0f)
            .method_27299(32)
            .method_27300(2)
            .method_5905("summeraot:grisha_titan_grab")
    );

    private GrishaEntities() {}

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(GRISHA_TITAN, AttackTitanEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GRISHA_NAPE, AttackTitanNapeEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GRISHA_EYE, AttackTitanEyeEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GRISHA_GRAB, AttackTitanGrabEntity.createAttributes());
    }
}
