package dev.summeraot.grisha;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import daot.HandcuffsTracker;
import dev.summeraot.SummerAOTPower;
import dev.summeraot.grisha.entity.GrishaTitanEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Collection;

/** Same independent command lifecycle as Krugger, no DAOT attack tag. */
public final class GrishaCommands {
    private GrishaCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            dispatcher.register(class_2170.method_9247("summeraot")
                .then(class_2170.method_9247("grisha")
                    .then(class_2170.method_9247("status").executes(ctx -> status(ctx.getSource())))
                    .then(class_2170.method_9247("select").executes(ctx -> select(ctx.getSource())))
                    .then(class_2170.method_9247("shift").executes(ctx -> shift(ctx.getSource())))
                    .then(class_2170.method_9247("grant").requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> grant(ctx.getSource(), class_2186.method_9315(ctx, "player")))))
                    .then(class_2170.method_9247("revoke").requires(source -> source.method_9259(2))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                            .executes(ctx -> revoke(ctx.getSource(), class_2186.method_9315(ctx, "player")))))
                    .then(class_2170.method_9247("summon").requires(source -> source.method_9259(2))
                        .executes(ctx -> summon(ctx.getSource())))));
            registerDaot(dispatcher);
        });
    }

    private static void registerDaot(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("daot")
            .then(class_2170.method_9247("shifter")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("set")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("grisha").executes(ctx -> {
                            Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
                            int count = 0;
                            for (class_3222 p : targets) if (SummerAOTPower.grantGrisha(p)) count++;
                            return count;
                        }))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .then(class_2170.method_9247("grisha").executes(ctx -> {
                            Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
                            int count = 0;
                            for (class_3222 p : targets) if (SummerAOTPower.revokeGrisha(p)) count++;
                            return count;
                        }))))));
    }

    private static int status(class_2168 source) throws CommandSyntaxException {
        class_3222 p = source.method_9207();
        source.method_9226(() -> class_2561.method_43470("SummerAOT Grisha: "
            + (SummerAOTPower.hasGrisha(p) ? "concedido" : "nao concedido")
            + ", selecionado=" + SummerAOTPower.isGrishaSelected(p)), false);
        return Command.SINGLE_SUCCESS;
    }
    private static int select(class_2168 source) throws CommandSyntaxException {
        class_3222 p = source.method_9207();
        if (!SummerAOTPower.hasGrisha(p) || !p.method_5805() || p.method_7325() || p.method_5765()) {
            source.method_9213(class_2561.method_43470("Grisha indisponivel para selecao."));
            return 0;
        }
        SummerAOTPower.selectGrisha(p);
        source.method_9226(() -> class_2561.method_43470("Grisha Titan selecionado."), false);
        return Command.SINGLE_SUCCESS;
    }
    private static int grant(class_2168 source, class_3222 target) {
        boolean changed = SummerAOTPower.grantGrisha(target);
        source.method_9226(() -> class_2561.method_43470("Grisha " + (changed ? "concedido" : "ja concedido")
            + ": " + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }
    private static int revoke(class_2168 source, class_3222 target) {
        boolean changed = SummerAOTPower.revokeGrisha(target);
        source.method_9226(() -> class_2561.method_43470("Grisha " + (changed ? "removido" : "nao presente")
            + ": " + target.method_5477().getString()), true);
        return Command.SINGLE_SUCCESS;
    }
    private static int shift(class_2168 source) throws CommandSyntaxException {
        class_3222 player = source.method_9207();
        if (!SummerAOTPower.hasGrisha(player) || !player.method_5805() || player.method_7325()
                || player.method_5765() || HandcuffsTracker.isCuffed(player.method_5667())) {
            source.method_9213(class_2561.method_43470("Nao e possivel transformar em Grisha neste estado."));
            return 0;
        }
        GrishaTitanEntity titan = GrishaEntities.GRISHA_TITAN.method_5883(player.method_51469());
        if (titan == null) return 0;
        titan.method_5808(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455());
        titan.setHardeningMode(0);
        if (!player.method_51469().method_8649(titan)) return 0;
        titan.spawnHitboxes();
        titan.onPlayerShift(player);
        return player.method_5854() == titan ? Command.SINGLE_SUCCESS : 0;
    }
    private static int summon(class_2168 source) {
        class_3218 world = source.method_9225();
        GrishaTitanEntity titan = GrishaEntities.GRISHA_TITAN.method_5883(world);
        if (titan == null) return 0;
        titan.method_5808(source.method_9222().field_1352, source.method_9222().field_1351,
            source.method_9222().field_1350, source.method_9210().field_1342, 0.0f);
        if (!world.method_8649(titan)) return 0;
        titan.spawnHitboxes();
        return Command.SINGLE_SUCCESS;
    }
}
